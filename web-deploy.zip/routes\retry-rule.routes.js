"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const retry_rule_controller_1 = require("../controllers/retry-rule.controller");
const auth_middleware_1 = require("../middleware/auth.middleware");
const validate_middleware_1 = require("../middleware/validate.middleware");
const retry_rule_validation_1 = require("../validations/retry-rule.validation");
const router = (0, express_1.Router)();
// Authenticated users can read retry rules to know default follow-up delays
router.get('/', auth_middleware_1.authenticate, retry_rule_controller_1.RetryRuleController.listRules);
// ADMIN and MANAGER can update retry rules
router.patch('/', auth_middleware_1.authenticate, (0, auth_middleware_1.authorize)('ADMIN', 'MANAGER'), (0, validate_middleware_1.validate)(retry_rule_validation_1.updateRetryRulesBulkSchema), retry_rule_controller_1.RetryRuleController.updateBulkRules);
router.patch('/:id', auth_middleware_1.authenticate, (0, auth_middleware_1.authorize)('ADMIN', 'MANAGER'), (0, validate_middleware_1.validate)(retry_rule_validation_1.updateSingleRetryRuleSchema), retry_rule_controller_1.RetryRuleController.updateSingleRule);
exports.default = router;
