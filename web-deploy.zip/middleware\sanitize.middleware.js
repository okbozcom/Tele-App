"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sanitizeNoSql = void 0;
const cleanObject = (obj) => {
    if (obj === null || typeof obj !== 'object') {
        return obj;
    }
    if (Array.isArray(obj)) {
        return obj.map(cleanObject);
    }
    const recordObj = obj;
    const cleaned = {};
    for (const key of Object.keys(recordObj)) {
        // Prohibit keys starting with '$' or containing '.' which can be used in MongoDB query injection
        if (key.startsWith('$') || key.includes('.')) {
            continue;
        }
        cleaned[key] = cleanObject(recordObj[key]);
    }
    return cleaned;
};
const sanitizeNoSql = (req, _res, next) => {
    if (req.body) {
        req.body = cleanObject(req.body);
    }
    if (req.query) {
        req.query = cleanObject(req.query);
    }
    if (req.params) {
        req.params = cleanObject(req.params);
    }
    next();
};
exports.sanitizeNoSql = sanitizeNoSql;
