"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhookIngestService = void 0;
const crypto_1 = __importDefault(require("crypto"));
const lead_model_1 = require("../models/lead.model");
const campaign_model_1 = require("../models/campaign.model");
const lead_assignment_service_1 = require("./lead-assignment.service");
const audit_service_1 = require("./audit.service");
const AppError_1 = require("../utils/AppError");
class WebhookIngestService {
    static verifySignature(payloadString, signatureHeader, secret = process.env.WEBHOOK_SECRET || 'hi_talk_default_webhook_secret_key_2026') {
        if (!signatureHeader)
            return false;
        const cleanSig = signatureHeader.replace(/^sha256=/, '').trim();
        const hmac = crypto_1.default.createHmac('sha256', secret);
        hmac.update(payloadString);
        const expected = hmac.digest('hex');
        try {
            return crypto_1.default.timingSafeEqual(Buffer.from(cleanSig, 'utf8'), Buffer.from(expected, 'utf8'));
        }
        catch {
            return false;
        }
    }
    static async ingestLead(payload, req) {
        if (!payload.phone || !payload.name) {
            throw new AppError_1.AppError('name and phone are required fields for webhook ingestion', 400);
        }
        // Resolve Campaign
        let campaign = null;
        if (payload.campaignId) {
            campaign = await campaign_model_1.Campaign.findById(payload.campaignId);
        }
        if (!campaign && payload.campaignName) {
            campaign = await campaign_model_1.Campaign.findOne({ name: payload.campaignName });
        }
        if (!campaign) {
            // Find default active campaign
            campaign = await campaign_model_1.Campaign.findOne({ isActive: true }).sort({ createdAt: 1 });
        }
        if (!campaign) {
            throw new AppError_1.AppError('No active campaign found to receive incoming webhook lead', 400);
        }
        // Map custom properties
        const customProps = new Map();
        if (payload.customProperties) {
            for (const [k, v] of Object.entries(payload.customProperties)) {
                customProps.set(k, String(v));
            }
        }
        // Auto-assign to available agent in campaign
        const assignedAgentId = await lead_assignment_service_1.LeadAssignmentService.assignLead(campaign, customProps);
        const lead = await lead_model_1.Lead.create({
            name: payload.name.trim(),
            phone: payload.phone.trim(),
            email: payload.email?.toLowerCase().trim(),
            campaignId: campaign._id,
            source: payload.source || 'WEBHOOK',
            stage: 'New',
            tag: payload.tag || 'COLD',
            status: 'OPEN',
            assignedTo: assignedAgentId,
            branch: null,
            customProperties: customProps,
        });
        await audit_service_1.AuditService.log({
            req,
            action: 'WEBHOOK_LEAD_INGEST',
            resourceType: 'LEAD',
            resourceId: lead._id.toString(),
            details: {
                campaignId: campaign._id.toString(),
                campaignName: campaign.name,
                assignedTo: assignedAgentId ? assignedAgentId.toString() : null,
            },
        });
        return lead;
    }
}
exports.WebhookIngestService = WebhookIngestService;
