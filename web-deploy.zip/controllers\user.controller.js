"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserController = void 0;
const user_service_1 = require("../services/user.service");
const AppError_1 = require("../utils/AppError");
class UserController {
    static async createUser(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const user = await user_service_1.UserService.createUser(req.user, req.body);
            res.status(201).json({
                user,
            });
        }
        catch (error) {
            next(error);
        }
    }
    static async listUsers(req, res, next) {
        try {
            // req.query is validated and cast by validate(listUsersQuerySchema)
            const users = await user_service_1.UserService.listUsers(req.user, req.query);
            res.status(200).json({
                users,
            });
        }
        catch (error) {
            next(error);
        }
    }
    static async updateUser(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const user = await user_service_1.UserService.updateUser(req.user, req.params.id, req.body);
            res.status(200).json({
                user,
            });
        }
        catch (error) {
            next(error);
        }
    }
    static async resetPassword(req, res, next) {
        try {
            const newPassword = req.body.password || req.body.newPassword;
            await user_service_1.UserService.resetPassword(req.params.id, newPassword);
            res.status(200).json({
                message: 'Password reset successfully',
            });
        }
        catch (error) {
            next(error);
        }
    }
    static async bulkCreate(req, res, next) {
        try {
            const users = await user_service_1.UserService.bulkCreateUsers(req.body);
            res.status(201).json({
                users,
            });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.UserController = UserController;
