"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LeadIngestService = void 0;
const mongoose_1 = require("mongoose");
const campaign_model_1 = require("../models/campaign.model");
const pipeline_model_1 = require("../models/pipeline.model");
const lead_model_1 = require("../models/lead.model");
const user_model_1 = require("../models/user.model");
const lead_assignment_service_1 = require("./lead-assignment.service");
const phone_util_1 = require("../utils/phone.util");
const AppError_1 = require("../utils/AppError");
class LeadIngestService {
    static async ingest(campaignId, rows, source = 'UPLOAD', targetAgentId) {
        const campaign = await campaign_model_1.Campaign.findById(campaignId);
        if (!campaign) {
            throw new AppError_1.AppError('Campaign not found', 404);
        }
        if (!campaign.isActive) {
            throw new AppError_1.AppError('Cannot ingest leads into an inactive campaign', 400);
        }
        // Retrieve the campaign's pipeline to get the initial stage
        const pipeline = await pipeline_model_1.Pipeline.findById(campaign.pipelineId);
        if (!pipeline || pipeline.stages.length === 0) {
            throw new AppError_1.AppError('Campaign pipeline is missing or contains no stages', 400);
        }
        const sortedStages = [...pipeline.stages].sort((a, b) => a.order - b.order);
        const initialStage = sortedStages[0];
        const result = {
            created: 0,
            merged: 0,
            skipped: 0,
            failed: [],
        };
        // Pre-cache active agents for fast matching
        const activeAgents = await user_model_1.User.find({ role: 'AGENT', isActive: true });
        const agentByEmail = new Map();
        const agentByName = new Map();
        const agentById = new Map();
        for (const ag of activeAgents) {
            agentByEmail.set(ag.email.toLowerCase(), ag._id);
            agentByName.set(ag.name.toLowerCase(), ag._id);
            agentById.set(ag._id.toString(), ag._id);
        }
        // Chunk size: 250 rows per batch
        const CHUNK_SIZE = 250;
        for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
            const chunk = rows.slice(i, i + CHUNK_SIZE);
            const validChunkRows = [];
            for (const row of chunk) {
                const name = typeof row.name === 'string' ? row.name.trim() : '';
                if (!name) {
                    result.failed.push({ row, reason: 'Missing or empty lead name' });
                    continue;
                }
                const normalizedPhone = (0, phone_util_1.normalizePhone)(row.phone);
                if (!normalizedPhone) {
                    result.failed.push({
                        row,
                        reason: 'Invalid phone number (must be a valid 10-digit number)',
                    });
                    continue;
                }
                const email = typeof row.email === 'string' ? row.email.trim().toLowerCase() : '';
                const customProperties = new Map();
                for (const [key, val] of Object.entries(row)) {
                    const lowerKey = key.toLowerCase();
                    if (lowerKey !== 'name' &&
                        lowerKey !== 'phone' &&
                        lowerKey !== 'email' &&
                        val !== undefined &&
                        val !== null) {
                        customProperties.set(key, String(val).trim());
                    }
                }
                validChunkRows.push({
                    row,
                    name,
                    normalizedPhone,
                    email,
                    customProperties,
                });
            }
            if (validChunkRows.length === 0)
                continue;
            // Batch query existing leads for the current chunk's phone numbers
            const chunkPhones = validChunkRows.map((r) => r.normalizedPhone);
            const existingLeads = await lead_model_1.Lead.find({
                campaignId: campaign._id,
                phone: { $in: chunkPhones },
            });
            const existingMap = new Map();
            for (const el of existingLeads) {
                existingMap.set(el.phone, el);
            }
            const leadsToInsert = [];
            for (const item of validChunkRows) {
                const existingLead = existingMap.get(item.normalizedPhone);
                if (existingLead) {
                    if (campaign.duplicateMode === 'SKIP') {
                        result.skipped += 1;
                        continue;
                    }
                    if (campaign.duplicateMode === 'MERGE') {
                        for (const [k, v] of item.customProperties.entries()) {
                            if (v)
                                existingLead.customProperties.set(k, v);
                        }
                        if (item.email && !existingLead.email) {
                            existingLead.email = item.email;
                        }
                        if (existingLead.status === 'CLOSED') {
                            const currentStageLower = (existingLead.stage || '').toLowerCase();
                            const isSuppressed = currentStageLower === 'not interested' ||
                                currentStageLower === 'lost' ||
                                currentStageLower === 'closed' ||
                                (existingLead.tag && existingLead.tag.toUpperCase() === 'DND');
                            if (!isSuppressed) {
                                existingLead.status = 'OPEN';
                                existingLead.stage = initialStage.name;
                                existingLead.tag = null;
                            }
                        }
                        await existingLead.save();
                        result.merged += 1;
                        continue;
                    }
                }
                // Resolve Assigned Agent
                let assignedTo = null;
                if (targetAgentId && mongoose_1.Types.ObjectId.isValid(targetAgentId)) {
                    assignedTo = new mongoose_1.Types.ObjectId(targetAgentId);
                }
                else if (item.row.assignedTo || item.row.agent) {
                    const ident = String(item.row.assignedTo || item.row.agent).trim();
                    assignedTo =
                        agentByEmail.get(ident.toLowerCase()) ||
                            agentByName.get(ident.toLowerCase()) ||
                            agentById.get(ident) ||
                            (await lead_assignment_service_1.LeadAssignmentService.assignLead(campaign, item.customProperties));
                }
                else {
                    assignedTo = await lead_assignment_service_1.LeadAssignmentService.assignLead(campaign, item.customProperties);
                }
                leadsToInsert.push({
                    campaignId: campaign._id,
                    name: item.name,
                    phone: item.normalizedPhone,
                    email: item.email,
                    source,
                    customProperties: item.customProperties,
                    assignedTo,
                    stage: initialStage.name,
                    tag: null,
                    status: initialStage.isClosed ? 'CLOSED' : 'OPEN',
                    attemptCount: 0,
                });
            }
            if (leadsToInsert.length > 0) {
                await lead_model_1.Lead.insertMany(leadsToInsert, { ordered: false });
                result.created += leadsToInsert.length;
            }
        }
        return result;
    }
}
exports.LeadIngestService = LeadIngestService;
