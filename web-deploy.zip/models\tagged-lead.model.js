"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TaggedLead = void 0;
const mongoose_1 = require("mongoose");
const taggedLeadSchema = new mongoose_1.Schema({
    leadId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Lead',
        required: [true, 'Lead ID is required'],
        index: true,
    },
    customerName: {
        type: String,
        required: [true, 'Customer name is required'],
        trim: true,
    },
    customerPhone: {
        type: String,
        required: [true, 'Customer phone is required'],
        trim: true,
    },
    agentId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'User',
        required: [true, 'Agent ID is required'],
        index: true,
    },
    agentName: {
        type: String,
        required: [true, 'Agent name is required'],
        trim: true,
    },
    branch: {
        type: String,
        default: null,
        trim: true,
        index: true,
    },
    targetRole: {
        type: String,
        enum: ['BOTH', 'MANAGER', 'ADMIN'],
        default: 'BOTH',
        index: true,
    },
    reason: {
        type: String,
        required: [true, 'Tag reason is required'],
        trim: true,
    },
    note: {
        type: String,
        default: '',
        trim: true,
    },
    dismissedBy: [
        {
            type: mongoose_1.Schema.Types.ObjectId,
            ref: 'User',
        },
    ],
    status: {
        type: String,
        enum: ['ACTIVE', 'DISMISSED'],
        default: 'ACTIVE',
        index: true,
    },
}, {
    timestamps: true,
});
taggedLeadSchema.index({ status: 1, targetRole: 1, branch: 1, createdAt: -1 });
exports.TaggedLead = (0, mongoose_1.model)('TaggedLead', taggedLeadSchema);
