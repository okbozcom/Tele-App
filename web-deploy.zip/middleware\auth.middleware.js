"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authorize = exports.authenticate = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const user_model_1 = require("../models/user.model");
const AppError_1 = require("../utils/AppError");
const authenticate = async (req, _res, next) => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            throw new AppError_1.AppError('Authentication required. Missing Bearer token.', 401);
        }
        const token = authHeader.split(' ')[1];
        const jwtSecret = process.env.JWT_SECRET;
        if (!jwtSecret) {
            throw new AppError_1.AppError('JWT_SECRET is not configured on the server', 500);
        }
        let decoded;
        try {
            decoded = jsonwebtoken_1.default.verify(token, jwtSecret);
        }
        catch {
            throw new AppError_1.AppError('Invalid or expired authentication token', 401);
        }
        const user = await user_model_1.User.findById(decoded.id);
        if (!user) {
            throw new AppError_1.AppError('The user belonging to this token no longer exists', 401);
        }
        if (!user.isActive) {
            throw new AppError_1.AppError('User account has been deactivated. Access denied.', 401);
        }
        if (decoded.tokenVersion !== undefined && user.tokenVersion !== undefined) {
            if (decoded.tokenVersion !== user.tokenVersion) {
                throw new AppError_1.AppError('Session has expired or was revoked. Please log in again.', 401);
            }
        }
        req.user = user;
        next();
    }
    catch (error) {
        next(error);
    }
};
exports.authenticate = authenticate;
const authorize = (...roles) => (req, _res, next) => {
    if (!req.user) {
        return next(new AppError_1.AppError('Authentication required.', 401));
    }
    if (!roles.includes(req.user.role)) {
        return next(new AppError_1.AppError('Forbidden: You do not have permission to perform this action', 403));
    }
    next();
};
exports.authorize = authorize;
