"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const path_1 = __importDefault(require("path"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const morgan_1 = __importDefault(require("morgan"));
const routes_1 = __importDefault(require("./routes"));
const errorHandler_1 = require("./middleware/errorHandler");
const rateLimiter_1 = require("./middleware/rateLimiter");
const compression_middleware_1 = require("./middleware/compression.middleware");
const sanitize_middleware_1 = require("./middleware/sanitize.middleware");
const AppError_1 = require("./utils/AppError");
const app = (0, express_1.default)();
// Trust reverse proxy (Render, Cloudflare, Heroku) to correctly identify client IP
app.set('trust proxy', 1);
// Security and utility middlewares
app.use(compression_middleware_1.compressionMiddleware);
app.use((0, helmet_1.default)({
    contentSecurityPolicy: false,
}));
app.use((0, cors_1.default)());
app.use(express_1.default.json());
app.use(express_1.default.urlencoded({ extended: true }));
app.use(sanitize_middleware_1.sanitizeNoSql);
if (process.env.NODE_ENV !== 'test') {
    app.use((0, morgan_1.default)('dev'));
}
// Public static assets & pages (Landing page, Privacy Policy, Terms)
const publicDir = path_1.default.join(__dirname, '../public');
app.use(express_1.default.static(publicDir));
app.get('/privacy', (_req, res) => {
    res.sendFile(path_1.default.join(publicDir, 'privacy.html'));
});
app.get('/terms', (_req, res) => {
    res.sendFile(path_1.default.join(publicDir, 'terms.html'));
});
app.get('/landing', (_req, res) => {
    res.sendFile(path_1.default.join(publicDir, 'landing.html'));
});
app.get('/about', (_req, res) => {
    res.sendFile(path_1.default.join(publicDir, 'landing.html'));
});
app.get(['/admin', '/admin/*'], (_req, res) => {
    res.sendFile(path_1.default.join(publicDir, 'admin/index.html'));
});
// Apply API rate limiter to protect against abuse and DDOS
app.use('/api', rateLimiter_1.apiLimiter);
// API Routes (supports both /api and /api/api to handle any duplicate prefixes gracefully)
app.use('/api/api', routes_1.default);
app.use('/api', routes_1.default);
// Catch-all for undefined routes
app.all('*', (req, _res, next) => {
    next(new AppError_1.AppError(`Cannot find ${req.originalUrl} on this server`, 404));
});
// Global error handling middleware
app.use(errorHandler_1.errorHandler);
exports.default = app;
