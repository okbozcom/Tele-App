"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActivityService = void 0;
const mongoose_1 = require("mongoose");
const activity_model_1 = require("../models/activity.model");
const lead_model_1 = require("../models/lead.model");
const campaign_model_1 = require("../models/campaign.model");
const user_model_1 = require("../models/user.model");
const pipeline_service_1 = require("./pipeline.service");
const setting_service_1 = require("./setting.service");
const retry_rule_service_1 = require("./retry-rule.service");
const lead_ingest_service_1 = require("./lead-ingest.service");
const audit_service_1 = require("./audit.service");
const AppError_1 = require("../utils/AppError");
class ActivityService {
    static async disposeLead(requester, leadId, input) {
        let lead = null;
        if (mongoose_1.Types.ObjectId.isValid(leadId)) {
            lead = await lead_model_1.Lead.findById(leadId);
        }
        // Fallback: If not found by _id, look up by phone if provided or from input
        const candidatePhone = input.phone || (leadId.replace(/\D/g, '').length >= 7 ? leadId : null);
        if (!lead && candidatePhone) {
            const cleanPhone = candidatePhone.replace(/\D/g, '').slice(-10);
            lead = await lead_model_1.Lead.findOne({ phone: { $regex: cleanPhone } });
        }
        // Check IdempotencyKey first: If already processed, return existing activity and lead
        if (input.idempotencyKey) {
            const existingActivity = await activity_model_1.Activity.findOne({ idempotencyKey: input.idempotencyKey });
            if (existingActivity) {
                const resolvedLead = lead || (await lead_model_1.Lead.findById(existingActivity.leadId));
                return {
                    activity: existingActivity,
                    lead: resolvedLead,
                };
            }
        }
        // If still not found, locate a default campaign and auto-create/upsert lead
        if (!lead) {
            const defaultCampaign = await campaign_model_1.Campaign.findOne();
            if (!defaultCampaign) {
                throw new AppError_1.AppError('Lead not found and no active campaign exists', 404);
            }
            const rawPhone = candidatePhone || '9810000129';
            lead = await lead_model_1.Lead.create({
                name: 'Lead ' + rawPhone.slice(-4),
                phone: rawPhone,
                campaignId: defaultCampaign._id,
                assignedTo: requester._id,
                stage: input.stage || 'New',
                status: 'OPEN',
            });
        }
        let campaign = await campaign_model_1.Campaign.findById(lead.campaignId);
        if (!campaign) {
            campaign = await campaign_model_1.Campaign.findOne();
            if (!campaign) {
                throw new AppError_1.AppError('Associated campaign not found', 404);
            }
            lead.campaignId = campaign._id;
        }
        // Permission & IDOR check:
        if (requester.role === 'AGENT') {
            if (lead.assignedTo && lead.assignedTo.toString() !== requester._id.toString()) {
                throw new AppError_1.AppError('Forbidden: You can only dispose leads assigned to you', 403);
            }
            if (!lead.assignedTo) {
                lead.assignedTo = requester._id;
            }
        }
        else if (requester.role === 'MANAGER') {
            const isManagerOfCampaign = campaign.managerId?.toString() === requester._id.toString();
            const isSameBranch = requester.branch && lead.branch && requester.branch.toLowerCase() === lead.branch.toLowerCase();
            if (!isManagerOfCampaign && !isSameBranch) {
                throw new AppError_1.AppError('Forbidden: You do not manage this lead or campaign', 403);
            }
        }
        const settings = await setting_service_1.SettingService.getSettings();
        const isCallAttempt = input.callAttempt;
        if (input.connected) {
            // Stage is required when connected
            const stageName = input.stage;
            const stageDoc = await pipeline_service_1.PipelineService.getStage(campaign.pipelineId, stageName);
            const normalizedStageName = stageName.trim().toLowerCase();
            const standaloneClosingStages = {
                closed: 'Closed',
                lost: 'Lost',
                'customer lost': 'Customer Lost',
                dnd: 'DND',
                'do not call': 'Do Not Call',
                junk: 'Junk',
                dropped: 'Dropped',
            };
            const standaloneClosingStage = standaloneClosingStages[normalizedStageName];
            // "Closed" is a disposition state in the app even when a campaign pipeline
            // doesn't define it as a stage (the default pipeline uses "Lost" instead).
            if (!stageDoc && !standaloneClosingStage) {
                throw new AppError_1.AppError(`Stage '${stageName}' does not exist in the campaign's pipeline`, 400);
            }
            // If tag is provided, verify it belongs to this stage (case-insensitive & accept standard temperature tags)
            if (input.tag) {
                const lowerTag = input.tag.toLowerCase();
                const stageTagsLower = (stageDoc?.tags || []).map((t) => t.toLowerCase());
                const standardTags = ['hot', 'warm', 'cold'];
                if (stageTagsLower.length > 0 &&
                    !stageTagsLower.includes(lowerTag) &&
                    !standardTags.includes(lowerTag)) {
                    throw new AppError_1.AppError(`Tag '${input.tag}' does not belong to stage '${stageDoc?.name || standaloneClosingStage}'`, 400);
                }
            }
            // Check if the stage closes the lead (isClosed flag, or Not Interested / Lost / Closed stage names)
            const stageLower = (stageDoc?.name || standaloneClosingStage || '').trim().toLowerCase();
            const isClosingStage = Boolean(stageDoc?.isClosed) ||
                stageLower === 'not interested' ||
                stageLower === 'lost' ||
                stageLower === 'closed' ||
                stageLower === 'customer lost' ||
                stageLower === 'dnd' ||
                stageLower === 'do not call' ||
                stageLower === 'junk' ||
                stageLower === 'dropped';
            if (isClosingStage) {
                lead.status = 'CLOSED';
                lead.nextFollowUpAt = null;
            }
            else {
                lead.status = 'OPEN';
                // Follow-up required unless allowDisposeWithoutFollowUp org setting is true
                if (!settings.allowDisposeWithoutFollowUp && !input.followUpAt) {
                    throw new AppError_1.AppError('followUpAt is required when disposing a non-closed connected lead', 400);
                }
                lead.nextFollowUpAt = input.followUpAt ? new Date(input.followUpAt) : null;
            }
            lead.stage = stageDoc?.name || standaloneClosingStage || stageName;
            lead.tag = input.tag || null;
            lead.followUpDue = false;
        }
        else {
            // Not connected - count consecutive not-connected attempts
            const previousActivities = isCallAttempt
                ? await activity_model_1.Activity.find({ leadId: lead._id, type: 'CALL' })
                    .sort({ createdAt: -1 })
                    .limit(20)
                : [];
            let consecutiveAttempts = 1; // Including this current call attempt
            for (const act of previousActivities) {
                if (!act.connected) {
                    consecutiveAttempts++;
                }
                else {
                    break;
                }
            }
            // Check if retry rule applies or if number is permanently unusable (P9 compliance)
            const reason = input.notConnectedReason || 'DID_NOT_PICK';
            const isPermanentlyUnreachable = reason === 'INVALID_NUMBER' ||
                reason === 'NUMBER_NOT_IN_USE' ||
                reason === 'INCOMING_NOT_AVAILABLE';
            if (isPermanentlyUnreachable) {
                lead.status = 'CLOSED';
                lead.nextFollowUpAt = null;
                lead.stage = 'Closed (Invalid)';
                lead.followUpDue = false;
            }
            else {
                const rule = await retry_rule_service_1.RetryRuleService.getRuleByReason(reason);
                const agentFollowUp = input.followUpAt ? new Date(input.followUpAt) : null;
                let computedFollowUp = retry_rule_service_1.RetryRuleService.calculateRetryFollowUp(rule, consecutiveAttempts, agentFollowUp);
                // If neither agentFollowUp nor computedFollowUp is present, default to 2 hours from now adjusted for calling hours
                if (!agentFollowUp && !computedFollowUp) {
                    computedFollowUp = retry_rule_service_1.RetryRuleService.adjustForCallingHours(new Date(Date.now() + 2 * 60 * 60 * 1000));
                }
                lead.nextFollowUpAt = agentFollowUp || computedFollowUp;
                lead.stage = isCallAttempt ? 'Not Connected' : input.stage || 'Not Connected';
                if (input.tag) {
                    lead.tag = input.tag;
                }
                lead.followUpDue = false;
            }
        }
        // Reassignment if requested
        if (input.reassignToUserId) {
            if (!mongoose_1.Types.ObjectId.isValid(input.reassignToUserId)) {
                throw new AppError_1.AppError('Invalid reassignToUserId format', 400);
            }
            const targetUser = await user_model_1.User.findById(input.reassignToUserId);
            if (!targetUser || !targetUser.isActive) {
                throw new AppError_1.AppError('reassignToUserId must be an active user', 400);
            }
            if (targetUser.role === 'AGENT' && !targetUser.canReceiveLeads) {
                throw new AppError_1.AppError('Target agent must have canReceiveLeads enabled', 400);
            }
            const previousAssignedTo = lead.assignedTo;
            lead.assignedTo = targetUser._id;
            await audit_service_1.AuditService.log({
                userId: requester._id,
                userEmail: requester.email,
                userRole: requester.role,
                action: 'LEAD_REASSIGN',
                resourceType: 'LEAD',
                resourceId: lead._id.toString(),
                details: {
                    fromUser: previousAssignedTo?.toString(),
                    toUser: targetUser._id.toString(),
                    campaignId: lead.campaignId.toString(),
                    dispositionStage: lead.stage,
                },
            });
        }
        // Copy to another campaign if requested
        if (input.copyToCampaignId) {
            const customPropsObj = {};
            lead.customProperties.forEach((value, key) => {
                customPropsObj[key] = value;
            });
            const copyRow = {
                name: lead.name,
                phone: lead.phone,
                email: lead.email,
                ...customPropsObj,
            };
            await lead_ingest_service_1.LeadIngestService.ingest(input.copyToCampaignId, [copyRow], 'CAMPAIGN_COPY');
        }
        // A repeated post-call submission must not increment the lead twice.
        const recentActivity = isCallAttempt
            ? await activity_model_1.Activity.findOne({
                leadId: lead._id,
                userId: requester._id,
                type: 'CALL',
                connected: input.connected,
                createdAt: { $gte: new Date(Date.now() - 4000) },
            }).sort({ createdAt: -1 })
            : null;
        if (recentActivity) {
            return { activity: recentActivity, lead };
        }
        // Update contact timestamp so dialed or disposed leads always move to the bottom of the queue
        lead.lastContactedAt = new Date();
        if (input.dealAmount !== undefined && input.dealAmount !== null) {
            lead.dealAmount = input.dealAmount;
            if (input.currency) {
                lead.currency = input.currency;
            }
        }
        const isIncoming = input.direction === 'INCOMING';
        if (!isIncoming) {
            if (isCallAttempt) {
                lead.attemptCount += 1;
            }
            else if (!lead.attemptCount || lead.attemptCount === 0) {
                lead.attemptCount = 1;
            }
        }
        await lead.save();
        // Create Activity log
        const activity = await activity_model_1.Activity.create({
            leadId: lead._id,
            phone: lead.phone || input.phone || null,
            branch: requester.branch || lead.branch || null,
            campaignId: lead.campaignId,
            userId: requester._id,
            type: isCallAttempt ? 'CALL' : 'UPDATE',
            direction: input.direction || 'OUTGOING',
            connected: isCallAttempt && input.connected,
            notConnectedReason: isCallAttempt && !input.connected ? (input.notConnectedReason || 'DID_NOT_PICK') : null,
            stage: lead.stage || input.stage || 'New',
            tag: lead.tag || input.tag || null,
            remark: input.remark || null,
            followUpAt: lead.nextFollowUpAt,
            durationSeconds: isCallAttempt && input.connected ? input.durationSeconds || 0 : 0,
            answers: input.answers || [],
            callLogId: input.callLogId || null,
            idempotencyKey: input.idempotencyKey || null,
            classificationReason: input.classificationReason || null,
            dealAmount: input.dealAmount ?? null,
            currency: input.currency || 'INR',
        });
        return { activity, lead };
    }
    static async getLeadHistory(_requester, leadId) {
        let lead = null;
        if (mongoose_1.Types.ObjectId.isValid(leadId)) {
            lead = await lead_model_1.Lead.findById(leadId);
        }
        if (!lead && leadId.replace(/\D/g, '').length >= 7) {
            const cleanPhone = leadId.replace(/\D/g, '').slice(-10);
            lead = await lead_model_1.Lead.findOne({ phone: { $regex: cleanPhone } });
        }
        const query = {};
        if (lead) {
            query.$or = [
                { leadId: lead._id },
                ...(lead.phone ? [{ phone: { $regex: lead.phone.replace(/\D/g, '').slice(-10) } }] : []),
            ];
        }
        else {
            const clean = leadId.replace(/\D/g, '').slice(-10);
            query.$or = [
                ...(mongoose_1.Types.ObjectId.isValid(leadId) ? [{ leadId: new mongoose_1.Types.ObjectId(leadId) }] : []),
                ...(clean.length >= 7 ? [{ phone: { $regex: clean } }] : [{ phone: leadId }]),
            ];
        }
        const rawActivities = await activity_model_1.Activity.find(query)
            .populate('userId', 'name email role branch')
            .sort({ createdAt: -1 });
        // Deduplicate any legacy or simultaneous duplicate records created within 15 seconds
        const deduplicated = [];
        for (const act of rawActivities) {
            const actTime = new Date(act.createdAt).getTime();
            const isDuplicate = deduplicated.some((existing) => {
                if (existing._id.toString() === act._id.toString())
                    return true;
                const existingTime = new Date(existing.createdAt).getTime();
                if (Math.abs(existingTime - actTime) < 15000) {
                    const sameStage = (existing.stage || '').toLowerCase().trim() === (act.stage || '').toLowerCase().trim();
                    const sameConnected = existing.connected === act.connected;
                    if (existing.type === act.type && sameStage && sameConnected) {
                        return true;
                    }
                }
                return false;
            });
            if (!isDuplicate) {
                deduplicated.push(act);
            }
        }
        return deduplicated;
    }
    static async getUserActivities(requester, query) {
        const filter = { type: 'CALL' };
        // If requester is an AGENT, strictly scope to their own userId
        if (requester.role === 'AGENT') {
            filter.userId = requester._id;
        }
        else if (query.userId) {
            if (mongoose_1.Types.ObjectId.isValid(query.userId)) {
                filter.userId = new mongoose_1.Types.ObjectId(query.userId);
            }
            else {
                const cleanQuery = query.userId.trim();
                const userMatch = await user_model_1.User.findOne({
                    $or: [
                        { email: new RegExp("^" + cleanQuery + "$", "i") },
                        { name: new RegExp("^" + cleanQuery + "$", "i") },
                    ],
                });
                if (userMatch) {
                    filter.userId = userMatch._id;
                }
                else {
                    filter.userId = new mongoose_1.Types.ObjectId();
                }
            }
        }
        else if (requester.role === 'MANAGER' && requester.branch) {
            filter.branch = new RegExp(`^${requester.branch.trim()}$`, 'i');
        }
        if (query.from || query.to) {
            const dateRange = {};
            if (query.from)
                dateRange.$gte = new Date(query.from);
            if (query.to)
                dateRange.$lte = new Date(query.to);
            filter.createdAt = dateRange;
        }
        if (query.stage && query.stage !== 'ALL') {
            filter.stage = new RegExp(query.stage.trim(), 'i');
        }
        if (query.connected !== undefined && query.connected !== '') {
            filter.connected = query.connected === 'true';
        }
        const limitNum = query.limit ? Math.min(Number(query.limit) || 500, 1000) : 500;
        const activities = await activity_model_1.Activity.find(filter)
            .sort({ createdAt: -1 })
            .limit(limitNum)
            .populate('leadId', 'name phone temperature tag stage')
            .populate('userId', 'name email branch')
            .lean();
        return activities.map((rawAct) => {
            const act = rawAct;
            const leadObj = act.leadId && typeof act.leadId === 'object' ? act.leadId : null;
            const userObj = act.userId && typeof act.userId === 'object' ? act.userId : null;
            const customerName = leadObj?.name ||
                (act.phone ? `Customer (${act.phone})` : 'Lead Contact');
            const phone = act.phone || leadObj?.phone || '';
            const temperature = act.tag || leadObj?.temperature || leadObj?.tag || 'WARM';
            return {
                _id: String(act._id),
                leadId: leadObj?._id ? String(leadObj._id) : act.leadId ? String(act.leadId) : '',
                campaignId: act.campaignId ? String(act.campaignId) : '',
                userId: userObj?._id ? String(userObj._id) : act.userId ? String(act.userId) : requester._id.toString(),
                agentName: userObj?.name || requester.name,
                customerName,
                phone,
                type: act.type,
                direction: act.direction || 'OUTGOING',
                connected: Boolean(act.connected),
                notConnectedReason: act.notConnectedReason || null,
                stage: act.stage || 'New',
                tag: temperature,
                temperature,
                remark: act.remark || '',
                followUpAt: act.followUpAt ? new Date(act.followUpAt).toISOString() : null,
                durationSeconds: act.durationSeconds || 0,
                branch: act.branch || userObj?.branch || null,
                callLogId: act.callLogId || null,
                idempotencyKey: act.idempotencyKey || null,
                dealAmount: act.dealAmount !== undefined ? act.dealAmount : null,
                currency: act.currency || 'INR',
                createdAt: act.createdAt ? new Date(act.createdAt).toISOString() : new Date().toISOString(),
                updatedAt: act.updatedAt ? new Date(act.updatedAt).toISOString() : new Date().toISOString(),
            };
        });
    }
    static async getBranchCallStats(branchName) {
        const match = { type: 'CALL' };
        if (branchName && branchName !== 'ALL') {
            match.branch = branchName;
        }
        const stats = await activity_model_1.Activity.aggregate([
            ...(Object.keys(match).length > 0 ? [{ $match: match }] : []),
            {
                $group: {
                    _id: '$branch',
                    totalCalls: { $sum: 1 },
                    connectedCalls: {
                        $sum: { $cond: [{ $eq: ['$connected', true] }, 1, 0] },
                    },
                    notConnectedCalls: {
                        $sum: { $cond: [{ $eq: ['$connected', false] }, 1, 0] },
                    },
                    totalDurationSeconds: { $sum: '$durationSeconds' },
                    uniqueAgents: { $addToSet: '$userId' },
                },
            },
            {
                $project: {
                    branch: { $ifNull: ['$_id', 'Unassigned'] },
                    totalCalls: 1,
                    connectedCalls: 1,
                    notConnectedCalls: 1,
                    totalDurationSeconds: 1,
                    activeAgentCount: { $size: '$uniqueAgents' },
                },
            },
            { $sort: { totalCalls: -1 } },
        ]);
        return stats;
    }
}
exports.ActivityService = ActivityService;
