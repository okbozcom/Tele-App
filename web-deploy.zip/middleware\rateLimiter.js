"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authLimiter = exports.apiLimiter = void 0;
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
/**
 * General API Rate Limiter
 * 300 requests per 15 minutes per IP.
 * Skips health check requests so uptime monitors & keep-alive pings are never throttled.
 */
exports.apiLimiter = (0, express_rate_limit_1.default)({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 3000, // High throughput for active telecalling sessions & auto-refresh
    standardHeaders: true,
    legacyHeaders: false,
    message: {
        status: 'error',
        message: 'Too many requests from this IP. Please try again after 15 minutes.',
    },
    skip: (req) => {
        // Never throttle health checks or active polling
        return (req.path === '/health' ||
            req.path === '/api/health' ||
            req.originalUrl.includes('/health'));
    },
});
/**
 * Strict Auth Rate Limiter
 * 30 login attempts per 15 minutes per IP.
 * Prevents credential stuffing and brute-force attacks against agents and admins.
 */
exports.authLimiter = (0, express_rate_limit_1.default)({
    windowMs: 15 * 60 * 1000,
    max: 30,
    standardHeaders: true,
    legacyHeaders: false,
    message: {
        status: 'error',
        message: 'Too many login attempts from this IP. Please try again after 15 minutes.',
    },
});
