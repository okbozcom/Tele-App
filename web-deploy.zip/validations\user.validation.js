"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.listUsersQuerySchema = exports.bulkCreateUsersSchema = exports.resetPasswordSchema = exports.updateUserSchema = exports.createUserSchema = void 0;
const zod_1 = require("zod");
exports.createUserSchema = zod_1.z.object({
    body: zod_1.z.object({
        name: zod_1.z.string({ required_error: 'Name is required' }).min(1, 'Name cannot be empty').trim(),
        email: zod_1.z
            .string({ required_error: 'Email is required' })
            .email('Invalid email address')
            .trim()
            .toLowerCase(),
        phone: zod_1.z.string({ required_error: 'Phone is required' }).min(5, 'Invalid phone number').trim(),
        password: zod_1.z
            .string({ required_error: 'Password is required' })
            .min(6, 'Password must be at least 6 characters long'),
        role: zod_1.z.enum(['ADMIN', 'MANAGER', 'AGENT'], {
            required_error: 'Role must be ADMIN, MANAGER, or AGENT',
        }),
        branch: zod_1.z.string().trim().optional().nullable(),
        managerId: zod_1.z
            .string()
            .regex(/^[0-9a-fA-F]{24}$/, 'Invalid manager ID format')
            .optional()
            .nullable(),
        isActive: zod_1.z.boolean().optional(),
        canReceiveLeads: zod_1.z.boolean().optional(),
    }),
});
exports.updateUserSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().regex(/^[0-9a-fA-F]{24}$/, 'Invalid user ID format'),
    }),
    body: zod_1.z
        .object({
        name: zod_1.z.string().min(1, 'Name cannot be empty').trim().optional(),
        phone: zod_1.z.string().min(5, 'Invalid phone number').trim().optional(),
        role: zod_1.z.enum(['ADMIN', 'MANAGER', 'AGENT']).optional(),
        branch: zod_1.z.string().trim().optional().nullable(),
        isActive: zod_1.z.boolean().optional(),
        canReceiveLeads: zod_1.z.boolean().optional(),
        managerId: zod_1.z
            .string()
            .regex(/^[0-9a-fA-F]{24}$/, 'Invalid manager ID format')
            .optional()
            .nullable(),
    })
        .refine((data) => Object.keys(data).length > 0, {
        message: 'At least one field must be provided for update',
    }),
});
exports.resetPasswordSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().regex(/^[0-9a-fA-F]{24}$/, 'Invalid user ID format'),
    }),
    body: zod_1.z
        .object({
        password: zod_1.z.string().min(6, 'Password must be at least 6 characters long').optional(),
        newPassword: zod_1.z.string().min(6, 'New password must be at least 6 characters long').optional(),
    })
        .refine((data) => Boolean(data.password || data.newPassword), {
        message: 'Either password or newPassword must be provided',
    }),
});
exports.bulkCreateUsersSchema = zod_1.z.object({
    body: zod_1.z
        .array(zod_1.z.object({
        name: zod_1.z.string({ required_error: 'Name is required' }).min(1).trim(),
        email: zod_1.z
            .string({ required_error: 'Email is required' })
            .email('Invalid email address')
            .trim()
            .toLowerCase(),
        phone: zod_1.z.string({ required_error: 'Phone is required' }).min(5).trim(),
        password: zod_1.z
            .string({ required_error: 'Password is required' })
            .min(6, 'Password must be at least 6 characters long'),
        role: zod_1.z.enum(['ADMIN', 'MANAGER', 'AGENT'], {
            required_error: 'Role must be ADMIN, MANAGER, or AGENT',
        }),
        branch: zod_1.z.string().trim().optional().nullable(),
        managerId: zod_1.z
            .string()
            .regex(/^[0-9a-fA-F]{24}$/, 'Invalid manager ID format')
            .optional()
            .nullable(),
        isActive: zod_1.z.boolean().optional(),
        canReceiveLeads: zod_1.z.boolean().optional(),
    }))
        .min(1, 'At least one user must be provided in bulk creation'),
});
exports.listUsersQuerySchema = zod_1.z.object({
    query: zod_1.z.object({
        role: zod_1.z.enum(['ADMIN', 'MANAGER', 'AGENT']).optional(),
        branch: zod_1.z.string().trim().optional(),
        isActive: zod_1.z
            .enum(['true', 'false'])
            .optional()
            .transform((val) => (val === undefined ? undefined : val === 'true')),
    }),
});
