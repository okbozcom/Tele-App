"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Pipeline = void 0;
const mongoose_1 = require("mongoose");
const stageSchema = new mongoose_1.Schema({
    name: {
        type: String,
        required: [true, 'Stage name is required'],
        trim: true,
    },
    isClosed: {
        type: Boolean,
        default: false,
    },
    tags: {
        type: [String],
        default: [],
    },
    order: {
        type: Number,
        default: 0,
    },
}, { _id: true });
const pipelineSchema = new mongoose_1.Schema({
    name: {
        type: String,
        required: [true, 'Pipeline name is required'],
        unique: true,
        trim: true,
    },
    stages: {
        type: [stageSchema],
        default: [],
    },
}, {
    timestamps: true,
});
exports.Pipeline = (0, mongoose_1.model)('Pipeline', pipelineSchema);
