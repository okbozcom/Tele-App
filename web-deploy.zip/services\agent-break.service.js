"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentBreakService = void 0;
const agent_break_model_1 = require("../models/agent-break.model");
const user_model_1 = require("../models/user.model");
const AppError_1 = require("../utils/AppError");
class AgentBreakService {
    static async startBreak(userId, reason = 'TEA') {
        const existing = await agent_break_model_1.AgentBreak.findOne({ userId, isActive: true });
        if (existing) {
            return existing;
        }
        const currentBreak = await agent_break_model_1.AgentBreak.create({
            userId,
            reason,
            startTime: new Date(),
            isActive: true,
        });
        // While on break, temporarily pause lead distribution to this agent
        await user_model_1.User.findByIdAndUpdate(userId, { canReceiveLeads: false });
        return currentBreak;
    }
    static async endBreak(userId) {
        const currentBreak = await agent_break_model_1.AgentBreak.findOne({ userId, isActive: true });
        if (!currentBreak) {
            throw new AppError_1.AppError('No active break found to end', 400);
        }
        const now = new Date();
        const durationMinutes = Math.max(1, Math.round((now.getTime() - new Date(currentBreak.startTime).getTime()) / 60000));
        currentBreak.endTime = now;
        currentBreak.durationMinutes = durationMinutes;
        currentBreak.isActive = false;
        await currentBreak.save();
        // Re-enable lead distribution
        await user_model_1.User.findByIdAndUpdate(userId, { canReceiveLeads: true });
        return currentBreak;
    }
    static async getCurrentBreak(userId) {
        return agent_break_model_1.AgentBreak.findOne({ userId, isActive: true });
    }
    static async getTodayBreaks(userId) {
        const startOfDay = new Date();
        startOfDay.setHours(0, 0, 0, 0);
        const breaks = await agent_break_model_1.AgentBreak.find({
            userId,
            startTime: { $gte: startOfDay },
        }).sort({ startTime: -1 });
        const activeBreak = breaks.find((b) => b.isActive) || null;
        const totalDurationMinutes = breaks.reduce((sum, b) => sum + (b.durationMinutes || 0), 0);
        return {
            breaks,
            totalDurationMinutes,
            activeBreak,
        };
    }
}
exports.AgentBreakService = AgentBreakService;
