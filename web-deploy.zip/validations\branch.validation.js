"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.branchIdParamSchema = exports.updateBranchSchema = exports.createBranchSchema = void 0;
const zod_1 = require("zod");
const objectIdRegex = /^[0-9a-fA-F]{24}$/;
exports.createBranchSchema = zod_1.z.object({
    body: zod_1.z.object({
        name: zod_1.z
            .string({ required_error: 'Branch name is required' })
            .min(2, 'Branch name must be at least 2 characters')
            .max(50, 'Branch name cannot exceed 50 characters')
            .trim(),
        code: zod_1.z.string().trim().max(10).optional(),
        address: zod_1.z.string().trim().max(200).optional(),
    }),
});
exports.updateBranchSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().regex(objectIdRegex, 'Invalid branch ID format'),
    }),
    body: zod_1.z.object({
        name: zod_1.z.string().min(2).max(50).trim().optional(),
        code: zod_1.z.string().trim().max(10).optional(),
        address: zod_1.z.string().trim().max(200).optional(),
        isActive: zod_1.z.boolean().optional(),
    }),
});
exports.branchIdParamSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().regex(objectIdRegex, 'Invalid branch ID format'),
    }),
});
