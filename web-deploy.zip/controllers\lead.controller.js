"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LeadController = void 0;
const mongoose_1 = require("mongoose");
const sync_1 = require("csv-parse/sync");
const lead_ingest_service_1 = require("../services/lead-ingest.service");
const lead_service_1 = require("../services/lead.service");
const webhook_ingest_service_1 = require("../services/webhook-ingest.service");
const campaign_model_1 = require("../models/campaign.model");
const AppError_1 = require("../utils/AppError");
class LeadController {
    static async uploadCsv(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            if (!req.file) {
                throw new AppError_1.AppError('CSV file is required in multipart form-data (key: "file")', 400);
            }
            let parsedRecords;
            try {
                parsedRecords = (0, sync_1.parse)(req.file.buffer, {
                    columns: true,
                    skip_empty_lines: true,
                    trim: true,
                });
            }
            catch {
                throw new AppError_1.AppError('Invalid CSV format. Please upload a well-formed CSV file.', 400);
            }
            if (parsedRecords.length === 0) {
                throw new AppError_1.AppError('The uploaded CSV file is empty', 400);
            }
            // Map rows extracting name, phone, email, agent and putting extra columns into custom properties
            const rows = parsedRecords.map((record) => {
                const row = {};
                for (const [key, value] of Object.entries(record)) {
                    const lowerKey = key.trim().toLowerCase();
                    if (lowerKey === 'name') {
                        row.name = String(value);
                    }
                    else if (lowerKey === 'phone' || lowerKey === 'mobile' || lowerKey === 'contact') {
                        row.phone = String(value);
                    }
                    else if (lowerKey === 'email') {
                        row.email = String(value);
                    }
                    else if (lowerKey === 'agent' ||
                        lowerKey === 'assignedto' ||
                        lowerKey === 'assigned_to' ||
                        lowerKey === 'agentemail' ||
                        lowerKey === 'agent_email') {
                        row.agent = String(value);
                    }
                    else {
                        row[key.trim()] = value;
                    }
                }
                return row;
            });
            const targetAgentId = req.body?.targetAgentId || undefined;
            const result = await lead_ingest_service_1.LeadIngestService.ingest(req.params.id, rows, 'UPLOAD', targetAgentId);
            res.status(200).json(result);
        }
        catch (error) {
            next(error);
        }
    }
    static async createWalkInLead(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            let campaignId = req.params.id;
            if (!campaignId ||
                campaignId === 'default' ||
                campaignId === 'default-campaign' ||
                !mongoose_1.Types.ObjectId.isValid(campaignId)) {
                const activeCamp = await campaign_model_1.Campaign.findOne({ isActive: true });
                if (activeCamp) {
                    campaignId = activeCamp._id.toString();
                }
                else {
                    const anyCamp = await campaign_model_1.Campaign.findOne();
                    if (anyCamp) {
                        campaignId = anyCamp._id.toString();
                    }
                    else {
                        throw new AppError_1.AppError('No campaign found to register walk-in lead.', 400);
                    }
                }
            }
            const row = {
                name: req.body.name,
                phone: req.body.phone,
                email: req.body.email,
                ...(req.body.customProperties || {}),
            };
            // If user is an AGENT, always assign the walk-in lead directly to them!
            const targetAgentId = req.user.role === 'AGENT'
                ? req.user._id.toString()
                : (req.body.assignedTo || undefined);
            const result = await lead_ingest_service_1.LeadIngestService.ingest(campaignId, [row], 'WALK_IN', targetAgentId);
            if (result.failed.length > 0) {
                throw new AppError_1.AppError(`Lead creation failed: ${result.failed[0].reason}`, 400);
            }
            res.status(201).json(result);
        }
        catch (error) {
            next(error);
        }
    }
    static async listCampaignLeads(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            // req.query is validated and typed by listCampaignLeadsQuerySchema
            const query = req.query;
            const result = await lead_service_1.LeadService.listCampaignLeads(req.user, req.params.id, query);
            res.status(200).json(result);
        }
        catch (error) {
            next(error);
        }
    }
    static async getMyLeads(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            // req.query is validated and typed by myLeadsQuerySchema
            const query = req.query;
            const result = await lead_service_1.LeadService.getMyLeads(req.user, query);
            res.status(200).json(result);
        }
        catch (error) {
            next(error);
        }
    }
    static async reassignLead(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const lead = await lead_service_1.LeadService.reassignLead(req.user, req.params.id, req.body.userId);
            res.status(200).json({ lead });
        }
        catch (error) {
            next(error);
        }
    }
    static async bulkReassign(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const result = await lead_service_1.LeadService.bulkReassign(req.user, req.body.fromUserId, req.body.toUserId, req.body.campaignId);
            res.status(200).json(result);
        }
        catch (error) {
            next(error);
        }
    }
    static async exportCampaignLeadsCsv(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const csv = await lead_service_1.LeadService.exportCampaignLeadsToCsv(req.user, req.params.id);
            res.setHeader('Content-Type', 'text/csv');
            res.setHeader('Content-Disposition', `attachment; filename="campaign-leads-${req.params.id}-${Date.now()}.csv"`);
            res.status(200).send(csv);
        }
        catch (error) {
            next(error);
        }
    }
    static async exportMyLeadsCsv(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const query = req.query;
            const csv = await lead_service_1.LeadService.exportMyLeadsToCsv(req.user, query);
            res.setHeader('Content-Type', 'text/csv');
            res.setHeader('Content-Disposition', `attachment; filename="my-leads-${Date.now()}.csv"`);
            res.status(200).send(csv);
        }
        catch (error) {
            next(error);
        }
    }
    static async updateLead(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const { id } = req.params;
            const { name, phone, email } = req.body;
            const lead = await lead_service_1.LeadService.updateLead(req.user, id, { name, phone, email });
            res.status(200).json({ status: 'ok', lead });
        }
        catch (error) {
            next(error);
        }
    }
    static async tagLeadToManager(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const taggedLead = await lead_service_1.LeadService.tagLeadToManager(req.user, {
                leadId: req.body.leadId || req.params.id,
                customerName: req.body.customerName,
                customerPhone: req.body.customerPhone,
                targetRole: req.body.targetRole,
                reason: req.body.reason,
                note: req.body.note,
            });
            res.status(201).json({ status: 'success', taggedLead });
        }
        catch (error) {
            next(error);
        }
    }
    static async getTaggedLeads(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const taggedLeads = await lead_service_1.LeadService.getTaggedLeads(req.user);
            res.status(200).json({ status: 'success', taggedLeads });
        }
        catch (error) {
            next(error);
        }
    }
    static async dismissTaggedLead(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const result = await lead_service_1.LeadService.dismissTaggedLead(req.user, req.params.id);
            res.status(200).json({ status: 'success', ...result });
        }
        catch (error) {
            next(error);
        }
    }
    static async handleWebhook(req, res, next) {
        try {
            const signature = req.headers['x-webhook-signature'] ||
                req.headers['x-hub-signature-256'];
            const secret = process.env.WEBHOOK_SECRET || 'hi_talk_default_webhook_secret_key_2026';
            const rawString = JSON.stringify(req.body);
            // Verify HMAC signature unless in non-production test without signature
            if (process.env.NODE_ENV === 'production' || signature) {
                const isValid = webhook_ingest_service_1.WebhookIngestService.verifySignature(rawString, signature, secret);
                if (!isValid) {
                    throw new AppError_1.AppError('Invalid or missing webhook signature', 401);
                }
            }
            const lead = await webhook_ingest_service_1.WebhookIngestService.ingestLead(req.body, req);
            res.status(201).json({
                status: 'success',
                message: 'Lead ingested successfully',
                data: { leadId: lead._id, assignedTo: lead.assignedTo },
            });
        }
        catch (err) {
            next(err);
        }
    }
}
exports.LeadController = LeadController;
