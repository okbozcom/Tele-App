"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditService = void 0;
const audit_log_model_1 = require("../models/audit-log.model");
const mongoose_1 = require("mongoose");
class AuditService {
    static async log(params) {
        try {
            const user = params.req?.user;
            const ipAddress = params.req?.ip ||
                params.req?.headers['x-forwarded-for'] ||
                params.req?.socket?.remoteAddress;
            const userAgent = params.req?.headers['user-agent'];
            return await audit_log_model_1.AuditLog.create({
                userId: params.userId || user?._id || null,
                userEmail: params.userEmail || user?.email,
                userRole: params.userRole || user?.role,
                action: params.action,
                resourceType: params.resourceType,
                resourceId: params.resourceId,
                details: params.details || {},
                ipAddress,
                userAgent,
            });
        }
        catch {
            // Never let audit logging failure crash business requests
            return null;
        }
    }
    static async getLogs(query) {
        const page = Math.max(1, query.page || 1);
        const limit = Math.min(100, Math.max(1, query.limit || 50));
        const filter = {};
        if (query.action)
            filter.action = query.action;
        if (query.resourceType)
            filter.resourceType = query.resourceType;
        if (query.userId)
            filter.userId = new mongoose_1.Types.ObjectId(query.userId);
        const [logs, total] = await Promise.all([
            audit_log_model_1.AuditLog.find(filter)
                .sort({ createdAt: -1 })
                .skip((page - 1) * limit)
                .limit(limit)
                .lean(),
            audit_log_model_1.AuditLog.countDocuments(filter),
        ]);
        return {
            logs: logs,
            total,
            page,
            limit,
        };
    }
}
exports.AuditService = AuditService;
