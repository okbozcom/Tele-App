"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.schedulerService = exports.CronSchedulerService = void 0;
const node_cron_1 = __importDefault(require("node-cron"));
const lead_model_1 = require("../models/lead.model");
const campaign_model_1 = require("../models/campaign.model");
const user_model_1 = require("../models/user.model");
const setting_service_1 = require("./setting.service");
const lead_assignment_service_1 = require("./lead-assignment.service");
const distributedLock_1 = require("../utils/distributedLock");
class CronSchedulerService {
    tasks = [];
    start() {
        // Check due follow-ups every minute with PM2 cluster distributed lock
        const followUpTask = node_cron_1.default.schedule('* * * * *', async () => {
            const lockKey = 'SCHEDULER_CHECK_FOLLOWUPS';
            const acquired = await distributedLock_1.DistributedLock.acquire(lockKey, 55);
            if (!acquired)
                return;
            try {
                await this.checkDueFollowUps();
            }
            catch (err) {
                console.error('[Scheduler] Error checking due follow-ups:', err);
            }
            finally {
                await distributedLock_1.DistributedLock.release(lockKey);
            }
        });
        // Check overdue leads of deactivated agents hourly with distributed lock
        const reassignTask = node_cron_1.default.schedule('0 * * * *', async () => {
            const lockKey = 'SCHEDULER_REASSIGN_OVERDUE';
            const acquired = await distributedLock_1.DistributedLock.acquire(lockKey, 300);
            if (!acquired)
                return;
            try {
                await this.reassignOverdueDeactivatedAgentLeads();
            }
            catch (err) {
                console.error('[Scheduler] Error reassigning overdue leads of deactivated agents:', err);
            }
            finally {
                await distributedLock_1.DistributedLock.release(lockKey);
            }
        });
        this.tasks.push(followUpTask, reassignTask);
        console.log('[Scheduler] CronSchedulerService started.');
    }
    stop() {
        for (const task of this.tasks) {
            task.stop();
        }
        this.tasks = [];
        console.log('[Scheduler] CronSchedulerService stopped.');
    }
    async checkDueFollowUps() {
        const now = new Date();
        const result = await lead_model_1.Lead.updateMany({
            status: 'OPEN',
            nextFollowUpAt: { $lte: now, $ne: null },
            followUpDue: false,
        }, {
            $set: { followUpDue: true },
        });
        return result.modifiedCount;
    }
    async reassignOverdueDeactivatedAgentLeads() {
        const settings = await setting_service_1.SettingService.getSettings();
        const hours = settings.reassignAfterHours ?? 24;
        const cutoff = new Date(Date.now() - hours * 60 * 60 * 1000);
        // Find deactivated agents
        const deactivatedAgents = await user_model_1.User.find({ role: 'AGENT', isActive: false }, '_id');
        if (deactivatedAgents.length === 0) {
            return 0;
        }
        const deactivatedAgentIds = deactivatedAgents.map((a) => a._id);
        // Find open leads assigned to deactivated agents where follow-up is overdue past cutoff
        const overdueLeads = await lead_model_1.Lead.find({
            assignedTo: { $in: deactivatedAgentIds },
            status: 'OPEN',
            nextFollowUpAt: { $lte: cutoff, $ne: null },
        });
        let reassignedCount = 0;
        for (const lead of overdueLeads) {
            const campaign = await campaign_model_1.Campaign.findById(lead.campaignId);
            if (!campaign || !campaign.isActive)
                continue;
            const newAgentId = await lead_assignment_service_1.LeadAssignmentService.assignLead(campaign, lead.customProperties);
            if (newAgentId && newAgentId.toString() !== lead.assignedTo?.toString()) {
                lead.assignedTo = newAgentId;
                await lead.save();
                reassignedCount++;
            }
        }
        return reassignedCount;
    }
}
exports.CronSchedulerService = CronSchedulerService;
exports.schedulerService = new CronSchedulerService();
