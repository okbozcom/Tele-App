"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReportController = void 0;
const report_service_1 = require("../services/report.service");
const AppError_1 = require("../utils/AppError");
class ReportController {
    static async getDashboard(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const query = req.query;
            const data = await report_service_1.ReportService.getDashboard(req.user, query);
            res.status(200).json(data);
        }
        catch (error) {
            next(error);
        }
    }
    static async getUserCalls(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const query = req.query;
            const data = await report_service_1.ReportService.getUserCalls(req.user, query);
            res.status(200).json({ agents: data });
        }
        catch (error) {
            next(error);
        }
    }
    static async getDispositions(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const query = req.query;
            const data = await report_service_1.ReportService.getDispositions(req.user, query);
            res.status(200).json({ dispositions: data });
        }
        catch (error) {
            next(error);
        }
    }
    static async getFollowUps(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const query = req.query;
            const data = await report_service_1.ReportService.getFollowUps(req.user, query);
            res.status(200).json({ followUps: data });
        }
        catch (error) {
            next(error);
        }
    }
    static async getCampaignStages(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const query = req.query;
            const data = await report_service_1.ReportService.getCampaignStages(req.user, query);
            res.status(200).json({ campaigns: data });
        }
        catch (error) {
            next(error);
        }
    }
    static async getCampaignLeads(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const query = req.query;
            const data = await report_service_1.ReportService.getCampaignLeads(req.user, query);
            res.status(200).json({ campaigns: data });
        }
        catch (error) {
            next(error);
        }
    }
    static async exportReport(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const query = req.query;
            const csv = await report_service_1.ReportService.exportReportToCsv(req.user, query);
            res.setHeader('Content-Type', 'text/csv');
            res.setHeader('Content-Disposition', `attachment; filename="report-${query.type}-${Date.now()}.csv"`);
            res.status(200).send(csv);
        }
        catch (error) {
            next(error);
        }
    }
}
exports.ReportController = ReportController;
