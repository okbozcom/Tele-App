"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const report_controller_1 = require("../controllers/report.controller");
const auth_middleware_1 = require("../middleware/auth.middleware");
const validate_middleware_1 = require("../middleware/validate.middleware");
const report_validation_1 = require("../validations/report.validation");
const router = (0, express_1.Router)();
// All reporting endpoints require authentication
router.use(auth_middleware_1.authenticate);
router.get('/dashboard', (0, validate_middleware_1.validate)(report_validation_1.reportQuerySchema), report_controller_1.ReportController.getDashboard);
router.get('/user-calls', (0, validate_middleware_1.validate)(report_validation_1.reportQuerySchema), report_controller_1.ReportController.getUserCalls);
router.get('/dispositions', (0, validate_middleware_1.validate)(report_validation_1.reportQuerySchema), report_controller_1.ReportController.getDispositions);
router.get('/follow-ups', (0, validate_middleware_1.validate)(report_validation_1.reportQuerySchema), report_controller_1.ReportController.getFollowUps);
router.get('/campaign-stages', (0, validate_middleware_1.validate)(report_validation_1.reportQuerySchema), report_controller_1.ReportController.getCampaignStages);
router.get('/campaign-leads', (0, validate_middleware_1.validate)(report_validation_1.reportQuerySchema), report_controller_1.ReportController.getCampaignLeads);
router.get('/export', (0, validate_middleware_1.validate)(report_validation_1.reportExportQuerySchema), report_controller_1.ReportController.exportReport);
exports.default = router;
