"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const mongoose_1 = require("mongoose");
const user_model_1 = require("../models/user.model");
const lead_model_1 = require("../models/lead.model");
const audit_service_1 = require("./audit.service");
const AppError_1 = require("../utils/AppError");
class UserService {
    static async createUser(requester, input) {
        let assignedBranch = input.branch || null;
        if (requester.role === 'MANAGER') {
            if (input.role !== 'AGENT') {
                throw new AppError_1.AppError('Managers can only create AGENT users', 403);
            }
            if (!input.managerId) {
                input.managerId = requester._id.toString();
            }
            if (requester.branch) {
                assignedBranch = requester.branch;
            }
        }
        const existingUser = await user_model_1.User.findOne({ email: input.email.toLowerCase() });
        if (existingUser) {
            throw new AppError_1.AppError('A user with this email already exists', 400);
        }
        const saltRounds = 10;
        const passwordHash = await bcryptjs_1.default.hash(input.password, saltRounds);
        const user = await user_model_1.User.create({
            name: input.name,
            email: input.email.toLowerCase(),
            phone: input.phone,
            passwordHash,
            role: input.role,
            branch: assignedBranch,
            managerId: input.managerId ? new mongoose_1.Types.ObjectId(input.managerId) : null,
            isActive: input.isActive ?? true,
            canReceiveLeads: input.canReceiveLeads ?? true,
        });
        await audit_service_1.AuditService.log({
            userId: requester._id,
            userEmail: requester.email,
            userRole: requester.role,
            action: 'USER_CREATE',
            resourceType: 'USER',
            resourceId: user._id.toString(),
            details: { email: user.email, role: user.role, branch: user.branch },
        });
        return user;
    }
    static async listUsers(requester, query = {}) {
        const filter = {};
        if (requester?.role === 'MANAGER' && requester.branch) {
            filter.branch = requester.branch;
            filter.role = 'AGENT';
        }
        else {
            if (query.role) {
                filter.role = query.role;
            }
            if (query.branch) {
                filter.branch = query.branch;
            }
        }
        if (query.isActive !== undefined) {
            filter.isActive = query.isActive;
        }
        const users = await user_model_1.User.find(filter)
            .populate('managerId', 'name email role branch')
            .sort({ createdAt: -1 });
        return users;
    }
    static async updateUser(requester, userId, updates) {
        const user = await user_model_1.User.findById(userId);
        if (!user) {
            throw new AppError_1.AppError('User not found', 404);
        }
        if (updates.role !== undefined && requester.role !== 'ADMIN') {
            throw new AppError_1.AppError('Only administrators can change user roles', 403);
        }
        if (requester.role === 'MANAGER' && user.role !== 'AGENT') {
            throw new AppError_1.AppError('Managers can only modify AGENT users', 403);
        }
        if (updates.name !== undefined)
            user.name = updates.name;
        if (updates.phone !== undefined)
            user.phone = updates.phone;
        if (updates.role !== undefined) {
            user.role = updates.role;
            user.tokenVersion = (user.tokenVersion || 0) + 1;
        }
        if (updates.branch !== undefined)
            user.branch = updates.branch;
        if (updates.isActive !== undefined) {
            if (user.isActive !== updates.isActive) {
                user.isActive = updates.isActive;
                if (!updates.isActive) {
                    user.tokenVersion = (user.tokenVersion || 0) + 1;
                }
            }
        }
        if (updates.canReceiveLeads !== undefined)
            user.canReceiveLeads = updates.canReceiveLeads;
        if (updates.managerId !== undefined) {
            user.managerId = updates.managerId ? new mongoose_1.Types.ObjectId(updates.managerId) : null;
        }
        await user.save();
        await audit_service_1.AuditService.log({
            userId: requester._id,
            userEmail: requester.email,
            userRole: requester.role,
            action: updates.isActive === false ? 'USER_DEACTIVATE' : 'USER_UPDATE',
            resourceType: 'USER',
            resourceId: user._id.toString(),
            details: { updates },
        });
        // P11.3: If agent is deactivated, automatically reassign open leads to active agents
        if (updates.isActive === false && user.role === 'AGENT') {
            const activeAgents = await user_model_1.User.find({
                role: 'AGENT',
                isActive: true,
                canReceiveLeads: true,
                _id: { $ne: user._id },
                ...(user.branch ? { branch: user.branch } : {}),
            });
            if (activeAgents.length > 0) {
                const targetAgent = activeAgents[0];
                const reassigned = await lead_model_1.Lead.updateMany({ assignedTo: user._id, status: 'OPEN' }, { $set: { assignedTo: targetAgent._id } });
                await audit_service_1.AuditService.log({
                    userId: requester._id,
                    userEmail: requester.email,
                    userRole: requester.role,
                    action: 'DEACTIVATED_AGENT_LEADS_REASSIGNED',
                    resourceType: 'USER',
                    resourceId: user._id.toString(),
                    details: {
                        fromUserId: user._id.toString(),
                        toUserId: targetAgent._id.toString(),
                        reassignedCount: reassigned.modifiedCount,
                    },
                });
            }
        }
        return user;
    }
    static async resetPassword(userId, newPassword) {
        const user = await user_model_1.User.findById(userId);
        if (!user) {
            throw new AppError_1.AppError('User not found', 404);
        }
        const saltRounds = 10;
        user.passwordHash = await bcryptjs_1.default.hash(newPassword, saltRounds);
        user.tokenVersion = (user.tokenVersion || 0) + 1;
        await user.save();
    }
    static async bulkCreateUsers(usersInput) {
        const emailsInPayload = usersInput.map((u) => u.email.toLowerCase());
        const uniqueEmails = new Set(emailsInPayload);
        if (uniqueEmails.size !== emailsInPayload.length) {
            throw new AppError_1.AppError('Duplicate email addresses detected in the provided users array', 400);
        }
        const existingUsers = await user_model_1.User.find({ email: { $in: Array.from(uniqueEmails) } });
        if (existingUsers.length > 0) {
            const duplicateList = existingUsers.map((u) => u.email).join(', ');
            throw new AppError_1.AppError(`The following email addresses already exist: ${duplicateList}`, 400);
        }
        const saltRounds = 10;
        const usersToCreate = await Promise.all(usersInput.map(async (u) => {
            const passwordHash = await bcryptjs_1.default.hash(u.password, saltRounds);
            return {
                name: u.name,
                email: u.email.toLowerCase(),
                phone: u.phone,
                passwordHash,
                role: u.role,
                branch: u.branch || null,
                managerId: u.managerId ? new mongoose_1.Types.ObjectId(u.managerId) : null,
                isActive: u.isActive ?? true,
                canReceiveLeads: u.canReceiveLeads ?? true,
            };
        }));
        const createdUsers = await user_model_1.User.insertMany(usersToCreate);
        return createdUsers;
    }
}
exports.UserService = UserService;
