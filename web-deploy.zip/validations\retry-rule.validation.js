"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateRetryRulesBulkSchema = exports.updateSingleRetryRuleSchema = void 0;
const zod_1 = require("zod");
const activity_model_1 = require("../models/activity.model");
const objectIdRegex = /^[0-9a-fA-F]{24}$/;
exports.updateSingleRetryRuleSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().regex(objectIdRegex, 'Invalid rule ID format'),
    }),
    body: zod_1.z
        .object({
        enabled: zod_1.z.boolean().optional(),
        steps: zod_1.z
            .array(zod_1.z.object({
            delayMinutes: zod_1.z.number().int().min(1, 'delayMinutes must be at least 1 minute'),
        }))
            .optional(),
    })
        .refine((data) => Object.keys(data).length > 0, {
        message: 'At least one field must be provided for update',
    }),
});
exports.updateRetryRulesBulkSchema = zod_1.z.object({
    body: zod_1.z
        .array(zod_1.z.object({
        reason: zod_1.z.enum(activity_model_1.NotConnectedReasons),
        enabled: zod_1.z.boolean(),
        steps: zod_1.z.array(zod_1.z.object({
            delayMinutes: zod_1.z.number().int().min(1, 'delayMinutes must be at least 1 minute'),
        })),
    }))
        .min(1, 'At least one rule must be provided for bulk update'),
});
