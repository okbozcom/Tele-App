"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const pipeline_controller_1 = require("../controllers/pipeline.controller");
const auth_middleware_1 = require("../middleware/auth.middleware");
const validate_middleware_1 = require("../middleware/validate.middleware");
const pipeline_validation_1 = require("../validations/pipeline.validation");
const router = (0, express_1.Router)();
// All pipeline endpoints require authentication
router.use(auth_middleware_1.authenticate);
// Reads: Any authenticated user can read pipelines
router.get('/', pipeline_controller_1.PipelineController.listPipelines);
router.get('/:id', (0, validate_middleware_1.validate)(pipeline_validation_1.pipelineIdParamSchema), pipeline_controller_1.PipelineController.getPipeline);
// Writes: ADMIN and MANAGER
router.post('/', (0, auth_middleware_1.authorize)('ADMIN', 'MANAGER'), (0, validate_middleware_1.validate)(pipeline_validation_1.createPipelineSchema), pipeline_controller_1.PipelineController.createPipeline);
router.patch('/:id', (0, auth_middleware_1.authorize)('ADMIN', 'MANAGER'), (0, validate_middleware_1.validate)(pipeline_validation_1.updatePipelineSchema), pipeline_controller_1.PipelineController.updatePipeline);
router.delete('/:id', (0, auth_middleware_1.authorize)('ADMIN', 'MANAGER'), (0, validate_middleware_1.validate)(pipeline_validation_1.pipelineIdParamSchema), pipeline_controller_1.PipelineController.deletePipeline);
exports.default = router;
