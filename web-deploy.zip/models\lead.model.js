"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Lead = void 0;
const mongoose_1 = require("mongoose");
const leadSchema = new mongoose_1.Schema({
    campaignId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Campaign',
        required: [true, 'Campaign ID is required'],
        index: true,
    },
    name: {
        type: String,
        required: [true, 'Name is required'],
        trim: true,
    },
    phone: {
        type: String,
        required: [true, 'Phone number is required'],
        trim: true,
        index: true,
    },
    email: {
        type: String,
        trim: true,
        lowercase: true,
        default: '',
    },
    source: {
        type: String,
        default: 'UPLOAD',
        trim: true,
    },
    branch: {
        type: String,
        default: null,
        trim: true,
        index: true,
    },
    customProperties: {
        type: Map,
        of: String,
        default: {},
    },
    assignedTo: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'User',
        default: null,
        index: true,
    },
    stage: {
        type: String,
        required: [true, 'Stage is required'],
        trim: true,
    },
    tag: {
        type: String,
        default: null,
        trim: true,
    },
    status: {
        type: String,
        enum: ['OPEN', 'CLOSED'],
        default: 'OPEN',
        index: true,
    },
    nextFollowUpAt: {
        type: Date,
        default: null,
        index: true,
    },
    followUpDue: {
        type: Boolean,
        default: false,
        index: true,
    },
    lastContactedAt: {
        type: Date,
        default: null,
    },
    attemptCount: {
        type: Number,
        default: 0,
        min: 0,
    },
}, {
    timestamps: true,
});
// Compound index for duplicate detection
leadSchema.index({ campaignId: 1, phone: 1 });
// Compound index for lead assignment and follow-up filtering
leadSchema.index({ campaignId: 1, assignedTo: 1, status: 1, nextFollowUpAt: 1 });
// Compound index for agent's my-leads queue and follow-up sorting
leadSchema.index({ assignedTo: 1, status: 1, nextFollowUpAt: 1 });
// High-speed compound indexes for 50k+ volume scaling:
leadSchema.index({ assignedTo: 1, status: 1, stage: 1, createdAt: -1 });
leadSchema.index({ campaignId: 1, status: 1, stage: 1 });
leadSchema.index({ branch: 1, status: 1, createdAt: -1 });
leadSchema.index({ createdAt: -1 });
exports.Lead = (0, mongoose_1.model)('Lead', leadSchema);
