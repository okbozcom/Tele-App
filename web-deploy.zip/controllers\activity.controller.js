"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActivityController = void 0;
const activity_service_1 = require("../services/activity.service");
const AppError_1 = require("../utils/AppError");
class ActivityController {
    static async disposeLead(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const result = await activity_service_1.ActivityService.disposeLead(req.user, req.params.id, req.body);
            res.status(200).json(result);
        }
        catch (error) {
            next(error);
        }
    }
    static async getLeadHistory(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const activities = await activity_service_1.ActivityService.getLeadHistory(req.user, req.params.id);
            res.status(200).json({ activities });
        }
        catch (error) {
            next(error);
        }
    }
    static async getUserActivities(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const activities = await activity_service_1.ActivityService.getUserActivities(req.user, req.query);
            res.status(200).json({ activities });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.ActivityController = ActivityController;
