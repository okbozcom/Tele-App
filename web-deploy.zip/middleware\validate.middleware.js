"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validate = void 0;
const validate = (schema) => async (req, _res, next) => {
    try {
        const parsed = await schema.parseAsync({
            body: req.body,
            query: req.query,
            params: req.params,
        });
        // Update request with parsed/sanitized/transformed values
        if (parsed.body !== undefined)
            req.body = parsed.body;
        if (parsed.query !== undefined)
            req.query = parsed.query;
        if (parsed.params !== undefined)
            req.params = parsed.params;
        next();
    }
    catch (error) {
        next(error);
    }
};
exports.validate = validate;
