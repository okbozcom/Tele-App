"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SchedulerLock = void 0;
const mongoose_1 = require("mongoose");
const schedulerLockSchema = new mongoose_1.Schema({
    lockKey: {
        type: String,
        required: true,
        unique: true,
    },
    lockedAt: {
        type: Date,
        default: Date.now,
    },
    lockedBy: {
        type: String,
        required: true,
    },
    expiresAt: {
        type: Date,
        required: true,
        index: { expires: 0 }, // Document automatically purged by MongoDB TTL when expiresAt is reached
    },
}, {
    timestamps: false,
});
exports.SchedulerLock = (0, mongoose_1.model)('SchedulerLock', schedulerLockSchema);
