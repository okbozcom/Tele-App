"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pipelineIdParamSchema = exports.updatePipelineSchema = exports.createPipelineSchema = void 0;
const zod_1 = require("zod");
const stageInputSchema = zod_1.z.object({
    _id: zod_1.z.string().regex(/^[0-9a-fA-F]{24}$/, 'Invalid stage ID format').optional(),
    name: zod_1.z
        .string({ required_error: 'Stage name is required' })
        .min(1, 'Stage name cannot be empty')
        .trim(),
    isClosed: zod_1.z.boolean().default(false),
    tags: zod_1.z.array(zod_1.z.string().trim()).default([]),
    order: zod_1.z.number().int().default(0),
});
const validateUniqueStageNames = (stages) => {
    if (!stages || stages.length === 0)
        return true;
    const names = stages.map((s) => s.name.trim().toLowerCase());
    const uniqueNames = new Set(names);
    return uniqueNames.size === names.length;
};
exports.createPipelineSchema = zod_1.z.object({
    body: zod_1.z
        .object({
        name: zod_1.z
            .string({ required_error: 'Pipeline name is required' })
            .min(1, 'Pipeline name cannot be empty')
            .trim(),
        stages: zod_1.z.array(stageInputSchema).default([]),
    })
        .refine((data) => validateUniqueStageNames(data.stages), {
        message: 'Stage names must be unique inside a pipeline',
        path: ['stages'],
    }),
});
exports.updatePipelineSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().regex(/^[0-9a-fA-F]{24}$/, 'Invalid pipeline ID format'),
    }),
    body: zod_1.z
        .object({
        name: zod_1.z.string().min(1, 'Pipeline name cannot be empty').trim().optional(),
        stages: zod_1.z.array(stageInputSchema).optional(),
    })
        .refine((data) => !data.stages || validateUniqueStageNames(data.stages), {
        message: 'Stage names must be unique inside a pipeline',
        path: ['stages'],
    })
        .refine((data) => Object.keys(data).length > 0, {
        message: 'At least one field must be provided for update',
    }),
});
exports.pipelineIdParamSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().regex(/^[0-9a-fA-F]{24}$/, 'Invalid pipeline ID format'),
    }),
});
