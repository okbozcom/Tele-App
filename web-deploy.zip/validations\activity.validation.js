"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.disposeLeadSchema = void 0;
const zod_1 = require("zod");
const activity_model_1 = require("../models/activity.model");
const objectIdRegex = /^[0-9a-fA-F]{24}$/;
exports.disposeLeadSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().min(1, 'Lead ID is required'),
    }),
    body: zod_1.z
        .object({
        phone: zod_1.z.string().optional().nullable(),
        connected: zod_1.z.boolean({ required_error: 'connected boolean is required' }),
        callAttempt: zod_1.z.boolean().default(false),
        notConnectedReason: zod_1.z.enum(activity_model_1.NotConnectedReasons).optional(),
        stage: zod_1.z.string().trim().optional(),
        tag: zod_1.z.string().trim().optional().nullable(),
        followUpAt: zod_1.z.string().datetime({ offset: true }).or(zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}/)).optional().nullable(),
        remark: zod_1.z.string().trim().optional().nullable(),
        durationSeconds: zod_1.z.number().int().min(0).default(0),
        direction: zod_1.z.enum(['OUTGOING', 'INCOMING']).default('OUTGOING').optional(),
        idempotencyKey: zod_1.z.string().trim().optional().nullable(),
        callLogId: zod_1.z.string().trim().optional().nullable(),
        classificationReason: zod_1.z.string().trim().optional().nullable(),
        dealAmount: zod_1.z.number().min(0).optional().nullable(),
        currency: zod_1.z.string().trim().default('INR').optional().nullable(),
        answers: zod_1.z
            .array(zod_1.z.object({
            questionId: zod_1.z.string().min(1),
            value: zod_1.z.unknown(),
        }))
            .default([]),
        reassignToUserId: zod_1.z.string().regex(objectIdRegex, 'Invalid target user ID').optional().nullable(),
        copyToCampaignId: zod_1.z.string().regex(objectIdRegex, 'Invalid copy campaign ID').optional().nullable(),
    })
        .superRefine((data, ctx) => {
        if (data.connected) {
            if (!data.stage || data.stage.trim().length === 0) {
                ctx.addIssue({
                    code: zod_1.z.ZodIssueCode.custom,
                    message: 'stage is required when connected is true',
                    path: ['stage'],
                });
            }
        }
    }),
});
