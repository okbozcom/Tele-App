"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateLeadSchema = exports.bulkReassignSchema = exports.reassignLeadSchema = exports.myLeadsQuerySchema = exports.listCampaignLeadsQuerySchema = exports.createLeadSchema = void 0;
const zod_1 = require("zod");
const objectIdRegex = /^[0-9a-fA-F]{24}$/;
exports.createLeadSchema = zod_1.z.object({
    body: zod_1.z.object({
        name: zod_1.z.string({ required_error: 'Name is required' }).min(1).trim(),
        phone: zod_1.z.string({ required_error: 'Phone number is required' }).min(5).trim(),
        email: zod_1.z.string().email('Invalid email address').trim().toLowerCase().optional().or(zod_1.z.literal('')),
        customProperties: zod_1.z.record(zod_1.z.string(), zod_1.z.string()).optional(),
    }),
});
exports.listCampaignLeadsQuerySchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().regex(objectIdRegex, 'Invalid campaign ID format'),
    }),
    query: zod_1.z.object({
        stage: zod_1.z.string().optional(),
        tag: zod_1.z.string().optional(),
        status: zod_1.z.enum(['OPEN', 'CLOSED']).optional(),
        assignedTo: zod_1.z.string().optional(),
        search: zod_1.z.string().optional(),
        startDate: zod_1.z.string().datetime({ offset: true }).or(zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/)).optional(),
        endDate: zod_1.z.string().datetime({ offset: true }).or(zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/)).optional(),
        page: zod_1.z
            .string()
            .optional()
            .transform((val) => (val ? parseInt(val, 10) : 1)),
        limit: zod_1.z
            .string()
            .optional()
            .transform((val) => (val ? parseInt(val, 10) : 5000)),
    }),
});
exports.myLeadsQuerySchema = zod_1.z.object({
    query: zod_1.z.object({
        type: zod_1.z.enum(['NEW', 'FOLLOW_UP', 'NOT_CONNECTED', 'ALL']).default('ALL'),
        campaignId: zod_1.z.string().regex(objectIdRegex, 'Invalid campaign ID format').optional(),
        userId: zod_1.z.string().regex(objectIdRegex, 'Invalid user ID format').optional(),
        page: zod_1.z
            .string()
            .optional()
            .transform((val) => (val ? parseInt(val, 10) : 1)),
        limit: zod_1.z
            .string()
            .optional()
            .transform((val) => (val ? parseInt(val, 10) : 5000)),
    }),
});
exports.reassignLeadSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().regex(objectIdRegex, 'Invalid lead ID format'),
    }),
    body: zod_1.z.object({
        userId: zod_1.z.string().regex(objectIdRegex, 'Invalid target user ID format'),
    }),
});
exports.bulkReassignSchema = zod_1.z.object({
    body: zod_1.z.object({
        fromUserId: zod_1.z.string().regex(objectIdRegex, 'Invalid fromUserId format'),
        toUserId: zod_1.z.string().regex(objectIdRegex, 'Invalid toUserId format'),
        campaignId: zod_1.z.string().regex(objectIdRegex, 'Invalid campaignId format').optional(),
    }),
});
exports.updateLeadSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().regex(objectIdRegex, 'Invalid lead ID format'),
    }),
    body: zod_1.z.object({
        name: zod_1.z.string().min(1).trim().optional(),
        phone: zod_1.z.string().min(5).trim().optional(),
        email: zod_1.z.string().email().trim().toLowerCase().optional().or(zod_1.z.literal('')),
    }),
});
