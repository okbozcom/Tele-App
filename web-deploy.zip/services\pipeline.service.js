"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.PipelineService = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const pipeline_model_1 = require("../models/pipeline.model");
const AppError_1 = require("../utils/AppError");
class PipelineService {
    static async listPipelines() {
        return pipeline_model_1.Pipeline.find().sort({ createdAt: -1 });
    }
    static async getPipelineById(id) {
        const pipeline = await pipeline_model_1.Pipeline.findById(id);
        if (!pipeline) {
            throw new AppError_1.AppError('Pipeline not found', 404);
        }
        return pipeline;
    }
    static async createPipeline(input) {
        const existing = await pipeline_model_1.Pipeline.findOne({ name: input.name });
        if (existing) {
            throw new AppError_1.AppError('A pipeline with this name already exists', 400);
        }
        // Ensure stage names are unique inside this pipeline
        const stageNames = input.stages.map((s) => s.name.trim().toLowerCase());
        if (new Set(stageNames).size !== stageNames.length) {
            throw new AppError_1.AppError('Stage names must be unique inside a pipeline', 400);
        }
        // Map stages with assigned order if not set
        const stagesWithOrder = input.stages.map((stage, index) => ({
            name: stage.name.trim(),
            isClosed: stage.isClosed ?? false,
            tags: stage.tags || [],
            order: stage.order !== undefined ? stage.order : index,
        }));
        const pipeline = await pipeline_model_1.Pipeline.create({
            name: input.name.trim(),
            stages: stagesWithOrder,
        });
        return pipeline;
    }
    static async updatePipeline(id, updates) {
        const pipeline = await pipeline_model_1.Pipeline.findById(id);
        if (!pipeline) {
            throw new AppError_1.AppError('Pipeline not found', 404);
        }
        if (updates.name && updates.name !== pipeline.name) {
            const duplicate = await pipeline_model_1.Pipeline.findOne({ name: updates.name });
            if (duplicate) {
                throw new AppError_1.AppError('Another pipeline with this name already exists', 400);
            }
            pipeline.name = updates.name.trim();
        }
        if (updates.stages) {
            // Validate unique stage names
            const stageNames = updates.stages.map((s) => s.name.trim().toLowerCase());
            if (new Set(stageNames).size !== stageNames.length) {
                throw new AppError_1.AppError('Stage names must be unique inside a pipeline', 400);
            }
            pipeline.stages = updates.stages.map((s, index) => ({
                ...(s._id ? { _id: new mongoose_1.Types.ObjectId(s._id) } : {}),
                name: s.name.trim(),
                isClosed: s.isClosed ?? false,
                tags: s.tags || [],
                order: s.order !== undefined ? s.order : index,
            }));
        }
        await pipeline.save();
        return pipeline;
    }
    static async deletePipeline(id) {
        const pipeline = await pipeline_model_1.Pipeline.findById(id);
        if (!pipeline) {
            throw new AppError_1.AppError('Pipeline not found', 404);
        }
        // Block deletion if any campaign uses this pipeline
        if (mongoose_1.default.modelNames().includes('Campaign')) {
            const Campaign = mongoose_1.default.model('Campaign');
            const inUseCount = await Campaign.countDocuments({ pipelineId: id });
            if (inUseCount > 0) {
                throw new AppError_1.AppError('Cannot delete pipeline because it is in use by one or more campaigns', 400);
            }
        }
        await pipeline.deleteOne();
    }
    /**
     * Helper to retrieve a specific stage by name from a pipeline.
     * Useful for downstream modules (Campaigns, Leads, Activities).
     */
    static async getStage(pipelineId, stageName) {
        const pipeline = await pipeline_model_1.Pipeline.findById(pipelineId);
        if (!pipeline) {
            return null;
        }
        const matched = pipeline.stages.find((s) => s.name.toLowerCase() === stageName.trim().toLowerCase());
        return matched || null;
    }
}
exports.PipelineService = PipelineService;
