"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const setting_controller_1 = require("../controllers/setting.controller");
const auth_middleware_1 = require("../middleware/auth.middleware");
const validate_middleware_1 = require("../middleware/validate.middleware");
const setting_validation_1 = require("../validations/setting.validation");
const router = (0, express_1.Router)();
// Public settings (accessible by any authenticated user for disposition rules)
router.get('/public', auth_middleware_1.authenticate, setting_controller_1.SettingController.getPublicSettings);
// Only ADMIN and MANAGER can view full settings or edit settings
router.use(auth_middleware_1.authenticate, (0, auth_middleware_1.authorize)('ADMIN', 'MANAGER'));
router.get('/', setting_controller_1.SettingController.getSettings);
router.patch('/', (0, validate_middleware_1.validate)(setting_validation_1.updateSettingSchema), setting_controller_1.SettingController.updateSettings);
exports.default = router;
