"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reportExportQuerySchema = exports.reportQuerySchema = void 0;
const zod_1 = require("zod");
const objectIdRegex = /^[0-9a-fA-F]{24}$/;
exports.reportQuerySchema = zod_1.z.object({
    query: zod_1.z.object({
        from: zod_1.z.string().datetime({ offset: true }).or(zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/)).optional(),
        to: zod_1.z.string().datetime({ offset: true }).or(zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/)).optional(),
        campaignId: zod_1.z.string().regex(objectIdRegex, 'Invalid campaign ID format').optional(),
        userId: zod_1.z.string().regex(objectIdRegex, 'Invalid user ID format').optional(),
        branch: zod_1.z.string().trim().optional(),
    }),
});
exports.reportExportQuerySchema = zod_1.z.object({
    query: zod_1.z.object({
        type: zod_1.z.enum([
            'dashboard',
            'user-calls',
            'call-logs',
            'dispositions',
            'follow-ups',
            'campaign-stages',
            'campaign-leads',
        ]),
        format: zod_1.z.enum(['csv']).default('csv'),
        from: zod_1.z.string().datetime({ offset: true }).or(zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/)).optional(),
        to: zod_1.z.string().datetime({ offset: true }).or(zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/)).optional(),
        campaignId: zod_1.z.string().regex(objectIdRegex, 'Invalid campaign ID format').optional(),
        userId: zod_1.z.string().regex(objectIdRegex, 'Invalid user ID format').optional(),
        branch: zod_1.z.string().trim().optional(),
    }),
});
