"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SettingController = void 0;
const setting_service_1 = require("../services/setting.service");
class SettingController {
    static async getSettings(_req, res, next) {
        try {
            const settings = await setting_service_1.SettingService.getSettings();
            res.status(200).json({ settings });
        }
        catch (error) {
            next(error);
        }
    }
    static async getPublicSettings(_req, res, next) {
        try {
            const settings = await setting_service_1.SettingService.getSettings();
            res.status(200).json({
                settings: {
                    allowDisposeWithoutFollowUp: settings.allowDisposeWithoutFollowUp,
                    followUpMandatoryForNotConnected: settings.followUpMandatoryForNotConnected,
                },
            });
        }
        catch (error) {
            next(error);
        }
    }
    static async updateSettings(req, res, next) {
        try {
            const settings = await setting_service_1.SettingService.updateSettings(req.body);
            res.status(200).json({ settings });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.SettingController = SettingController;
