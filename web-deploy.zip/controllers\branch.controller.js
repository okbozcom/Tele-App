"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BranchController = void 0;
const branch_service_1 = require("../services/branch.service");
const AppError_1 = require("../utils/AppError");
class BranchController {
    static async listBranches(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const branches = await branch_service_1.BranchService.listBranches();
            res.status(200).json({ branches });
        }
        catch (error) {
            next(error);
        }
    }
    static async createBranch(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const branch = await branch_service_1.BranchService.createBranch(req.user, req.body);
            res.status(201).json({ branch, message: 'Branch created successfully' });
        }
        catch (error) {
            next(error);
        }
    }
    static async deleteBranch(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            await branch_service_1.BranchService.deleteBranch(req.user, req.params.id);
            res.status(200).json({ message: 'Branch deleted successfully' });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.BranchController = BranchController;
