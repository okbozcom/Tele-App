"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SettingService = void 0;
const setting_model_1 = require("../models/setting.model");
class SettingService {
    static async getSettings() {
        let setting = await setting_model_1.Setting.findOne();
        if (!setting) {
            setting = await setting_model_1.Setting.create({
                allowDisposeWithoutFollowUp: false,
                followUpMandatoryForNotConnected: false,
            });
        }
        return setting;
    }
    static async updateSettings(updates) {
        const setting = await this.getSettings();
        if (updates.allowDisposeWithoutFollowUp !== undefined) {
            setting.allowDisposeWithoutFollowUp = updates.allowDisposeWithoutFollowUp;
        }
        if (updates.followUpMandatoryForNotConnected !== undefined) {
            setting.followUpMandatoryForNotConnected = updates.followUpMandatoryForNotConnected;
        }
        if (updates.reassignAfterHours !== undefined) {
            setting.reassignAfterHours = updates.reassignAfterHours;
        }
        await setting.save();
        return setting;
    }
}
exports.SettingService = SettingService;
