"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_1 = __importDefault(require("dotenv"));
const path_1 = __importDefault(require("path"));
// Load environment variables
dotenv_1.default.config();
dotenv_1.default.config({ path: path_1.default.resolve(__dirname, '../../.env') });
const mongoose_1 = __importDefault(require("mongoose"));
const lead_model_1 = require("../models/lead.model");
const activity_model_1 = require("../models/activity.model");
const user_model_1 = require("../models/user.model");
const campaign_model_1 = require("../models/campaign.model");
const pipeline_model_1 = require("../models/pipeline.model");
const cleanDatabase = async () => {
    const mongoURI = process.env.MONGO_URI ||
        process.env.MONGODB_URI ||
        'mongodb://localhost:27017/tele_app';
    try {
        console.log('[Cleanup] Connecting to MongoDB...');
        await mongoose_1.default.connect(mongoURI);
        console.log('[Cleanup] Connected to MongoDB Atlas successfully.');
        // 1. Check existing counts
        const leadCount = await lead_model_1.Lead.countDocuments();
        const activityCount = await activity_model_1.Activity.countDocuments();
        const userCount = await user_model_1.User.countDocuments();
        const campaignCount = await campaign_model_1.Campaign.countDocuments();
        const pipelineCount = await pipeline_model_1.Pipeline.countDocuments();
        console.log('\n--- Current Database Counts ---');
        console.log(`Leads (to delete): ${leadCount}`);
        console.log(`Activities / Call Logs (to delete): ${activityCount}`);
        console.log(`Users (preserved): ${userCount}`);
        console.log(`Campaigns (preserved): ${campaignCount}`);
        console.log(`Pipelines (preserved): ${pipelineCount}`);
        // 2. Delete test leads and test activities
        console.log('\n[Cleanup] Cleaning all test leads...');
        const deletedLeads = await lead_model_1.Lead.deleteMany({});
        console.log(`[Cleanup] Deleted ${deletedLeads.deletedCount} leads.`);
        console.log('[Cleanup] Cleaning all test call logs / activities...');
        const deletedActivities = await activity_model_1.Activity.deleteMany({});
        console.log(`[Cleanup] Deleted ${deletedActivities.deletedCount} activities.`);
        // 3. Verify clean state
        const remainingLeads = await lead_model_1.Lead.countDocuments();
        const remainingActivities = await activity_model_1.Activity.countDocuments();
        console.log('\n--- Final Verified Database Status ---');
        console.log(`Remaining Leads: ${remainingLeads} (100% Clean)`);
        console.log(`Remaining Activities: ${remainingActivities} (100% Clean)`);
        console.log(`Active Users: ${userCount} (Intact - Login Ready)`);
        console.log(`Campaigns: ${campaignCount} (Intact - Ready for Real Leads Upload)`);
        console.log('--------------------------------------\n');
        console.log('[Cleanup] Database is now 100% fresh and ready for real customer data upload!');
        await mongoose_1.default.disconnect();
        process.exit(0);
    }
    catch (error) {
        console.error('[Cleanup] Error cleaning database:', error);
        await mongoose_1.default.disconnect().catch(() => { });
        process.exit(1);
    }
};
cleanDatabase();
