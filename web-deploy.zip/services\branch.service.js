"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BranchService = void 0;
const branch_model_1 = require("../models/branch.model");
const user_model_1 = require("../models/user.model");
const AppError_1 = require("../utils/AppError");
const DEFAULT_BRANCHES = [
    { name: 'Trichy', code: 'TRZ', address: 'Trichy Main Office' },
    { name: 'Pudukkottai', code: 'PDK', address: 'Pudukkottai Branch Office' },
    { name: 'Chennai', code: 'MAA', address: 'Chennai Regional Office' },
    { name: 'Madurai', code: 'IXM', address: 'Madurai Branch Office' },
];
class BranchService {
    /**
     * Lists all branches. If none exist yet, automatically seeds default branches.
     */
    static async listBranches() {
        let branches = await branch_model_1.Branch.find().sort({ name: 1 });
        if (branches.length === 0) {
            try {
                await branch_model_1.Branch.insertMany(DEFAULT_BRANCHES.map((b) => ({
                    ...b,
                    isActive: true,
                    createdBy: null,
                })));
                branches = await branch_model_1.Branch.find().sort({ name: 1 });
            }
            catch (_err) {
                // If race condition or duplicate key on seed, ignore and re-query
                branches = await branch_model_1.Branch.find().sort({ name: 1 });
            }
        }
        return branches;
    }
    /**
     * Creates a new branch. Restricted to ADMIN users only.
     */
    static async createBranch(requester, input) {
        if (requester.role !== 'ADMIN') {
            throw new AppError_1.AppError('Forbidden: Only administrators can create branches', 403);
        }
        const trimmedName = input.name.trim();
        // Case-insensitive duplicate check
        const existing = await branch_model_1.Branch.findOne({
            name: { $regex: new RegExp(`^${trimmedName.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&')}$`, 'i') },
        });
        if (existing) {
            throw new AppError_1.AppError(`A branch named '${trimmedName}' already exists`, 409);
        }
        const branch = await branch_model_1.Branch.create({
            name: trimmedName,
            code: input.code ? input.code.trim().toUpperCase() : '',
            address: input.address ? input.address.trim() : '',
            isActive: true,
            createdBy: requester._id,
        });
        return branch;
    }
    /**
     * Deletes a branch. Restricted to ADMIN users only.
     */
    static async deleteBranch(requester, id) {
        if (requester.role !== 'ADMIN') {
            throw new AppError_1.AppError('Forbidden: Only administrators can delete branches', 403);
        }
        const branch = await branch_model_1.Branch.findById(id);
        if (!branch) {
            throw new AppError_1.AppError('Branch not found', 404);
        }
        // Safety check: Prevent deleting branch if users are assigned to it
        const userCount = await user_model_1.User.countDocuments({ branch: branch.name });
        if (userCount > 0) {
            throw new AppError_1.AppError(`Cannot delete branch '${branch.name}' because ${userCount} team member(s) are assigned to it. Please reassign them to another branch first.`, 400);
        }
        await branch.deleteOne();
    }
}
exports.BranchService = BranchService;
