"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentBreakController = void 0;
const agent_break_service_1 = require("../services/agent-break.service");
const AppError_1 = require("../utils/AppError");
class AgentBreakController {
    static async startBreak(req, res, next) {
        try {
            if (!req.user)
                throw new AppError_1.AppError('Authentication required', 401);
            const { reason } = req.body;
            const currentBreak = await agent_break_service_1.AgentBreakService.startBreak(req.user._id, reason);
            res.status(200).json({ status: 'ok', data: currentBreak });
        }
        catch (err) {
            next(err);
        }
    }
    static async endBreak(req, res, next) {
        try {
            if (!req.user)
                throw new AppError_1.AppError('Authentication required', 401);
            const finishedBreak = await agent_break_service_1.AgentBreakService.endBreak(req.user._id);
            res.status(200).json({ status: 'ok', data: finishedBreak });
        }
        catch (err) {
            next(err);
        }
    }
    static async getCurrentBreak(req, res, next) {
        try {
            if (!req.user)
                throw new AppError_1.AppError('Authentication required', 401);
            const activeBreak = await agent_break_service_1.AgentBreakService.getCurrentBreak(req.user._id);
            res.status(200).json({ status: 'ok', data: activeBreak });
        }
        catch (err) {
            next(err);
        }
    }
    static async getTodayBreaks(req, res, next) {
        try {
            if (!req.user)
                throw new AppError_1.AppError('Authentication required', 401);
            const summary = await agent_break_service_1.AgentBreakService.getTodayBreaks(req.user._id);
            res.status(200).json({ status: 'ok', data: summary });
        }
        catch (err) {
            next(err);
        }
    }
}
exports.AgentBreakController = AgentBreakController;
