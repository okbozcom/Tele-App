"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentBreak = void 0;
const mongoose_1 = require("mongoose");
const agentBreakSchema = new mongoose_1.Schema({
    userId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
        index: true,
    },
    reason: {
        type: String,
        enum: ['TEA', 'LUNCH', 'MEETING', 'PERSONAL', 'TRAINING'],
        default: 'TEA',
    },
    startTime: {
        type: Date,
        required: true,
        default: Date.now,
    },
    endTime: {
        type: Date,
        default: null,
    },
    durationMinutes: {
        type: Number,
        default: null,
    },
    isActive: {
        type: Boolean,
        default: true,
        index: true,
    },
}, {
    timestamps: true,
});
agentBreakSchema.index({ userId: 1, isActive: 1 });
agentBreakSchema.index({ userId: 1, startTime: -1 });
exports.AgentBreak = (0, mongoose_1.model)('AgentBreak', agentBreakSchema);
