"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.campaignIdParamSchema = exports.copyCampaignSchema = exports.updateCampaignSchema = exports.createCampaignSchema = void 0;
const zod_1 = require("zod");
const objectIdRegex = /^[0-9a-fA-F]{24}$/;
const questionTypeEnum = zod_1.z.enum([
    'TEXT',
    'SHORT_ANSWER',
    'NUMBER',
    'LONG_ANSWER',
    'DATE',
    'TIME',
    'MULTIPLE_CHOICE',
    'CHECKBOX',
    'DROPDOWN',
]);
const engagementQuestionInputSchema = zod_1.z.object({
    id: zod_1.z.string({ required_error: 'Question ID is required' }).min(1).trim(),
    type: questionTypeEnum,
    label: zod_1.z.string({ required_error: 'Question label is required' }).min(1).trim(),
    options: zod_1.z.array(zod_1.z.string().trim()).default([]),
    required: zod_1.z.boolean().default(false),
});
const conditionalRuleInputSchema = zod_1.z.object({
    field: zod_1.z.string({ required_error: 'Rule field is required' }).min(1).trim(),
    value: zod_1.z.string({ required_error: 'Rule value is required' }).min(1).trim(),
    agentIds: zod_1.z
        .array(zod_1.z.string().regex(objectIdRegex, 'Invalid agent ID format'))
        .min(1, 'Rule must assign at least one agent'),
});
exports.createCampaignSchema = zod_1.z.object({
    body: zod_1.z
        .object({
        name: zod_1.z
            .string({ required_error: 'Campaign name is required' })
            .min(1, 'Campaign name cannot be empty')
            .trim(),
        pipelineId: zod_1.z.string().regex(objectIdRegex, 'Invalid pipeline ID format'),
        managerId: zod_1.z.string().regex(objectIdRegex, 'Invalid manager ID format').optional(),
        agentIds: zod_1.z
            .array(zod_1.z.string().regex(objectIdRegex, 'Invalid agent ID format'))
            .default([]),
        distributionMode: zod_1.z.enum(['EQUAL', 'CONDITIONAL']).default('EQUAL'),
        conditionalRules: zod_1.z.array(conditionalRuleInputSchema).default([]),
        fallbackAgentId: zod_1.z
            .string()
            .regex(objectIdRegex, 'Invalid fallback agent ID format')
            .optional()
            .nullable(),
        priority: zod_1.z.enum(['HIGH', 'MEDIUM', 'LOW']).default('MEDIUM'),
        duplicateMode: zod_1.z.enum(['SKIP', 'MERGE', 'CREATE_NEW']).default('SKIP'),
        engagementForm: zod_1.z.array(engagementQuestionInputSchema).default([]),
        isActive: zod_1.z.boolean().default(true),
    })
        .superRefine((data, ctx) => {
        if (data.distributionMode === 'CONDITIONAL') {
            if (!data.conditionalRules || data.conditionalRules.length === 0) {
                ctx.addIssue({
                    code: zod_1.z.ZodIssueCode.custom,
                    message: 'conditionalRules are required when distributionMode is CONDITIONAL',
                    path: ['conditionalRules'],
                });
            }
            if (!data.fallbackAgentId) {
                ctx.addIssue({
                    code: zod_1.z.ZodIssueCode.custom,
                    message: 'fallbackAgentId is required when distributionMode is CONDITIONAL',
                    path: ['fallbackAgentId'],
                });
            }
        }
    }),
});
exports.updateCampaignSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().regex(objectIdRegex, 'Invalid campaign ID format'),
    }),
    body: zod_1.z
        .object({
        name: zod_1.z.string().min(1, 'Campaign name cannot be empty').trim().optional(),
        pipelineId: zod_1.z.string().regex(objectIdRegex, 'Invalid pipeline ID format').optional(),
        managerId: zod_1.z.string().regex(objectIdRegex, 'Invalid manager ID format').optional(),
        agentIds: zod_1.z.array(zod_1.z.string().regex(objectIdRegex, 'Invalid agent ID format')).optional(),
        distributionMode: zod_1.z.enum(['EQUAL', 'CONDITIONAL']).optional(),
        conditionalRules: zod_1.z.array(conditionalRuleInputSchema).optional(),
        fallbackAgentId: zod_1.z
            .string()
            .regex(objectIdRegex, 'Invalid fallback agent ID format')
            .optional()
            .nullable(),
        priority: zod_1.z.enum(['HIGH', 'MEDIUM', 'LOW']).optional(),
        duplicateMode: zod_1.z.enum(['SKIP', 'MERGE', 'CREATE_NEW']).optional(),
        engagementForm: zod_1.z.array(engagementQuestionInputSchema).optional(),
        isActive: zod_1.z.boolean().optional(),
    })
        .refine((data) => Object.keys(data).length > 0, {
        message: 'At least one field must be provided for update',
    })
        .superRefine((data, ctx) => {
        if (data.distributionMode === 'CONDITIONAL') {
            if (data.conditionalRules && data.conditionalRules.length === 0) {
                ctx.addIssue({
                    code: zod_1.z.ZodIssueCode.custom,
                    message: 'conditionalRules cannot be empty when distributionMode is CONDITIONAL',
                    path: ['conditionalRules'],
                });
            }
        }
    }),
});
exports.copyCampaignSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().regex(objectIdRegex, 'Invalid campaign ID format'),
    }),
    body: zod_1.z
        .object({
        name: zod_1.z.string().min(1).trim().optional(),
    })
        .optional(),
});
exports.campaignIdParamSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().regex(objectIdRegex, 'Invalid campaign ID format'),
    }),
});
