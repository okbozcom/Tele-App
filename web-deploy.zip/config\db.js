"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.connectDB = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const connectDB = async () => {
    const mongoURI = process.env.MONGO_URI || process.env.MONGODB_URI;
    if (!mongoURI) {
        console.warn('[Database] Warning: MONGO_URI is not defined in environment variables.');
        return;
    }
    try {
        const conn = await mongoose_1.default.connect(mongoURI, {
            serverSelectionTimeoutMS: 5000,
        });
        console.log(`[Database] MongoDB Connected: ${conn.connection.host}`);
    }
    catch (error) {
        console.error('[Database] MongoDB Connection Error: Could not connect to MongoDB.', error instanceof Error ? error.message : error);
        console.warn('[Database] Continuing server execution. Set a valid MONGO_URI in .env to use database features.');
    }
};
exports.connectDB = connectDB;
