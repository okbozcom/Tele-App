"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Activity = exports.NotConnectedReasons = void 0;
const mongoose_1 = require("mongoose");
exports.NotConnectedReasons = [
    'DID_NOT_PICK',
    'BUSY',
    'USER_DISCONNECTED',
    'SWITCHED_OFF',
    'OUT_OF_COVERAGE',
    'CALL_NOT_COMPLETED',
    'OTHER',
    'INVALID_NUMBER',
    'INCOMING_NOT_AVAILABLE',
    'NUMBER_NOT_IN_USE',
];
const engagementAnswerSchema = new mongoose_1.Schema({
    questionId: {
        type: String,
        required: true,
        trim: true,
    },
    value: {
        type: mongoose_1.Schema.Types.Mixed,
        default: null,
    },
}, { _id: false });
const activitySchema = new mongoose_1.Schema({
    leadId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Lead',
        required: [true, 'Lead ID is required'],
        index: true,
    },
    campaignId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Campaign',
        required: [true, 'Campaign ID is required'],
        index: true,
    },
    userId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'User',
        required: [true, 'User ID is required'],
        index: true,
    },
    type: {
        type: String,
        enum: ['CALL', 'UPDATE'],
        default: 'CALL',
    },
    direction: {
        type: String,
        enum: ['OUTGOING', 'INCOMING'],
        default: 'OUTGOING',
        index: true,
    },
    connected: {
        type: Boolean,
        required: [true, 'Connected status is required'],
    },
    notConnectedReason: {
        type: String,
        enum: exports.NotConnectedReasons,
        default: null,
    },
    stage: {
        type: String,
        required: [true, 'Stage is required'],
        trim: true,
    },
    tag: {
        type: String,
        default: null,
        trim: true,
    },
    remark: {
        type: String,
        default: null,
        trim: true,
    },
    followUpAt: {
        type: Date,
        default: null,
    },
    durationSeconds: {
        type: Number,
        default: 0,
        min: 0,
    },
    callLogId: {
        type: String,
        default: null,
        trim: true,
    },
    idempotencyKey: {
        type: String,
        default: null,
        trim: true,
    },
    classificationReason: {
        type: String,
        default: null,
        trim: true,
    },
    dealAmount: {
        type: Number,
        default: null,
    },
    currency: {
        type: String,
        default: 'INR',
        trim: true,
    },
    answers: {
        type: [engagementAnswerSchema],
        default: [],
    },
    phone: {
        type: String,
        default: null,
        trim: true,
        index: true,
    },
    branch: {
        type: String,
        default: null,
        trim: true,
        index: true,
    },
}, {
    timestamps: true,
});
activitySchema.index({ idempotencyKey: 1 }, { unique: true, sparse: true });
activitySchema.index({ leadId: 1, createdAt: -1 });
activitySchema.index({ phone: 1, direction: 1, createdAt: -1 });
activitySchema.index({ userId: 1, direction: 1, createdAt: -1 });
activitySchema.index({ phone: 1, createdAt: -1 });
activitySchema.index({ branch: 1, createdAt: -1 });
activitySchema.index({ userId: 1, createdAt: -1 });
activitySchema.index({ createdAt: -1, branch: 1 });
exports.Activity = (0, mongoose_1.model)('Activity', activitySchema);
