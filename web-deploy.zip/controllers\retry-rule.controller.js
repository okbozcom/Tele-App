"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RetryRuleController = void 0;
const retry_rule_service_1 = require("../services/retry-rule.service");
class RetryRuleController {
    static async listRules(_req, res, next) {
        try {
            const rules = await retry_rule_service_1.RetryRuleService.getOrCreateDefaultRules();
            res.status(200).json({ rules });
        }
        catch (error) {
            next(error);
        }
    }
    static async updateSingleRule(req, res, next) {
        try {
            const rule = await retry_rule_service_1.RetryRuleService.updateRule(req.params.id, req.body);
            res.status(200).json({ rule });
        }
        catch (error) {
            next(error);
        }
    }
    static async updateBulkRules(req, res, next) {
        try {
            const rules = await retry_rule_service_1.RetryRuleService.updateRulesBulk(req.body);
            res.status(200).json({ rules });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.RetryRuleController = RetryRuleController;
