"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.CampaignService = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const campaign_model_1 = require("../models/campaign.model");
const lead_model_1 = require("../models/lead.model");
const pipeline_model_1 = require("../models/pipeline.model");
const user_model_1 = require("../models/user.model");
const AppError_1 = require("../utils/AppError");
class CampaignService {
    static async validateAgents(agentIdStrings) {
        if (agentIdStrings.length === 0)
            return;
        const uniqueIdStrings = Array.from(new Set(agentIdStrings));
        const objectIds = uniqueIdStrings.map((id) => new mongoose_1.Types.ObjectId(id));
        const users = await user_model_1.User.find({ _id: { $in: objectIds } });
        if (users.length !== uniqueIdStrings.length) {
            throw new AppError_1.AppError('One or more assigned agents do not exist', 400);
        }
        for (const u of users) {
            if (u.role !== 'AGENT') {
                throw new AppError_1.AppError(`User '${u.name}' (${u.email}) is not an AGENT`, 400);
            }
            if (!u.isActive) {
                throw new AppError_1.AppError(`Agent '${u.name}' (${u.email}) is deactivated`, 400);
            }
        }
    }
    static async validatePipeline(pipelineId) {
        const pipeline = await pipeline_model_1.Pipeline.findById(pipelineId);
        if (!pipeline) {
            throw new AppError_1.AppError('Specified pipeline does not exist', 400);
        }
    }
    static async createCampaign(requester, input) {
        await this.validatePipeline(input.pipelineId);
        // Collect all agent IDs that need validation
        const agentsToValidate = [...input.agentIds];
        if (input.conditionalRules) {
            for (const rule of input.conditionalRules) {
                agentsToValidate.push(...rule.agentIds);
            }
        }
        if (input.fallbackAgentId) {
            agentsToValidate.push(input.fallbackAgentId);
        }
        await this.validateAgents(agentsToValidate);
        // Determine manager ID
        let managerId;
        if (requester.role === 'MANAGER') {
            managerId = requester._id;
        }
        else {
            if (input.managerId) {
                const mgr = await user_model_1.User.findById(input.managerId);
                if (!mgr || (mgr.role !== 'MANAGER' && mgr.role !== 'ADMIN') || !mgr.isActive) {
                    throw new AppError_1.AppError('Assigned manager must be an active MANAGER or ADMIN user', 400);
                }
                managerId = mgr._id;
            }
            else {
                managerId = requester._id;
            }
        }
        const campaign = await campaign_model_1.Campaign.create({
            name: input.name.trim(),
            pipelineId: new mongoose_1.Types.ObjectId(input.pipelineId),
            managerId,
            agentIds: input.agentIds.map((id) => new mongoose_1.Types.ObjectId(id)),
            distributionMode: input.distributionMode,
            conditionalRules: input.conditionalRules.map((rule) => ({
                field: rule.field.trim(),
                value: rule.value.trim(),
                agentIds: rule.agentIds.map((id) => new mongoose_1.Types.ObjectId(id)),
            })),
            fallbackAgentId: input.fallbackAgentId ? new mongoose_1.Types.ObjectId(input.fallbackAgentId) : null,
            priority: input.priority,
            duplicateMode: input.duplicateMode,
            engagementForm: input.engagementForm,
            isActive: input.isActive ?? true,
        });
        return campaign;
    }
    static async listCampaigns(requester) {
        let query = {};
        if (requester.role === 'ADMIN') {
            query = {};
        }
        else if (requester.role === 'MANAGER') {
            query = { managerId: requester._id };
        }
        else if (requester.role === 'AGENT') {
            const assignedCampaignIds = await lead_model_1.Lead.distinct('campaignId', { assignedTo: requester._id });
            query = {
                $or: [
                    { agentIds: requester._id, isActive: true },
                    { _id: { $in: assignedCampaignIds }, isActive: true },
                    { agentIds: { $size: 0 }, isActive: true },
                    { isActive: true },
                ],
            };
        }
        const campaigns = await campaign_model_1.Campaign.find(query)
            .populate('pipelineId', 'name')
            .populate('managerId', 'name email')
            .populate('agentIds', 'name email phone')
            .sort({ createdAt: -1 });
        if (campaigns.length === 0) {
            return [];
        }
        // Aggregate real lead statistics for each campaign from MongoDB
        const campIds = campaigns.map((c) => c._id);
        const leadMatch = { campaignId: { $in: campIds } };
        if (requester.role === 'AGENT') {
            leadMatch.assignedTo = requester._id;
        }
        const leadCounts = await lead_model_1.Lead.aggregate([
            { $match: leadMatch },
            {
                $group: {
                    _id: '$campaignId',
                    total: { $sum: 1 },
                    newCount: {
                        $sum: {
                            $cond: [
                                { $or: [{ $eq: ['$attemptCount', 0] }, { $not: ['$attemptCount'] }] },
                                1,
                                0,
                            ],
                        },
                    },
                    followUpCount: {
                        $sum: {
                            $cond: [
                                {
                                    $or: [
                                        { $eq: ['$stage', 'Follow Up'] },
                                        { $eq: ['$stage', 'Follow-up'] },
                                        { $ne: [{ $ifNull: ['$nextFollowUpAt', null] }, null] },
                                    ],
                                },
                                1,
                                0,
                            ],
                        },
                    },
                },
            },
        ]);
        const countMap = new Map();
        for (const item of leadCounts) {
            countMap.set(item._id.toString(), {
                total: item.total,
                newCount: item.newCount,
                followUpCount: item.followUpCount,
            });
        }
        const result = campaigns.map((camp) => {
            const campObj = camp.toObject ? camp.toObject() : camp;
            const stats = countMap.get(camp._id.toString()) || { total: 0, newCount: 0, followUpCount: 0 };
            return {
                ...campObj,
                totalLeads: stats.total,
                newLeads: stats.newCount,
                followUpLeads: stats.followUpCount,
            };
        });
        return result;
    }
    static async getCampaignById(requester, id) {
        const campaign = await campaign_model_1.Campaign.findById(id)
            .populate('pipelineId')
            .populate('managerId', 'name email role')
            .populate('agentIds', 'name email phone isActive')
            .populate('fallbackAgentId', 'name email');
        if (!campaign) {
            throw new AppError_1.AppError('Campaign not found', 404);
        }
        // Access authorization check
        if (requester.role === 'MANAGER') {
            if (campaign.managerId._id.toString() !== requester._id.toString()) {
                throw new AppError_1.AppError('Forbidden: You can only view your own campaigns', 403);
            }
        }
        else if (requester.role === 'AGENT') {
            const isAssigned = campaign.agentIds.some((agent) => agent._id.toString() === requester._id.toString());
            if (!isAssigned) {
                throw new AppError_1.AppError('Forbidden: You are not assigned to this campaign', 403);
            }
        }
        return campaign;
    }
    static async updateCampaign(requester, id, updates) {
        const campaign = await campaign_model_1.Campaign.findById(id);
        if (!campaign) {
            throw new AppError_1.AppError('Campaign not found', 404);
        }
        if (requester.role === 'MANAGER' && campaign.managerId.toString() !== requester._id.toString()) {
            throw new AppError_1.AppError('Forbidden: You can only edit your own campaigns', 403);
        }
        if (updates.pipelineId) {
            await this.validatePipeline(updates.pipelineId);
            campaign.pipelineId = new mongoose_1.Types.ObjectId(updates.pipelineId);
        }
        // Validate agents if agentIds, conditionalRules, or fallbackAgentId changed
        const agentsToValidate = [];
        if (updates.agentIds)
            agentsToValidate.push(...updates.agentIds);
        if (updates.conditionalRules) {
            for (const rule of updates.conditionalRules) {
                agentsToValidate.push(...rule.agentIds);
            }
        }
        if (updates.fallbackAgentId) {
            agentsToValidate.push(updates.fallbackAgentId);
        }
        if (agentsToValidate.length > 0) {
            await this.validateAgents(agentsToValidate);
        }
        let warning;
        // Check if distribution mode is modified on a campaign that already has leads
        if (updates.distributionMode && updates.distributionMode !== campaign.distributionMode) {
            if (mongoose_1.default.modelNames().includes('Lead')) {
                const Lead = mongoose_1.default.model('Lead');
                const leadCount = await Lead.countDocuments({ campaignId: id });
                if (leadCount > 0) {
                    warning =
                        'Warning: Leads already exist for this campaign. The distribution mode was changed, but existing leads will not be automatically redistributed.';
                }
            }
            campaign.distributionMode = updates.distributionMode;
        }
        if (updates.name !== undefined)
            campaign.name = updates.name.trim();
        if (updates.agentIds !== undefined) {
            campaign.agentIds = updates.agentIds.map((aid) => new mongoose_1.Types.ObjectId(aid));
        }
        if (updates.conditionalRules !== undefined) {
            campaign.conditionalRules = updates.conditionalRules.map((r) => ({
                field: r.field.trim(),
                value: r.value.trim(),
                agentIds: r.agentIds.map((aid) => new mongoose_1.Types.ObjectId(aid)),
            }));
        }
        if (updates.fallbackAgentId !== undefined) {
            campaign.fallbackAgentId = updates.fallbackAgentId
                ? new mongoose_1.Types.ObjectId(updates.fallbackAgentId)
                : null;
        }
        if (updates.priority !== undefined)
            campaign.priority = updates.priority;
        if (updates.duplicateMode !== undefined)
            campaign.duplicateMode = updates.duplicateMode;
        if (updates.engagementForm !== undefined)
            campaign.engagementForm = updates.engagementForm;
        if (updates.isActive !== undefined)
            campaign.isActive = updates.isActive;
        if (updates.managerId !== undefined && requester.role === 'ADMIN') {
            campaign.managerId = new mongoose_1.Types.ObjectId(updates.managerId);
        }
        // Check conditional mode completeness
        if (campaign.distributionMode === 'CONDITIONAL') {
            if (!campaign.conditionalRules || campaign.conditionalRules.length === 0) {
                throw new AppError_1.AppError('conditionalRules are required when distributionMode is CONDITIONAL', 400);
            }
            if (!campaign.fallbackAgentId) {
                throw new AppError_1.AppError('fallbackAgentId is required when distributionMode is CONDITIONAL', 400);
            }
        }
        await campaign.save();
        return { campaign, warning };
    }
    static async copyCampaign(requester, id, input) {
        const original = await campaign_model_1.Campaign.findById(id);
        if (!original) {
            throw new AppError_1.AppError('Original campaign not found', 404);
        }
        if (requester.role === 'MANAGER' && original.managerId.toString() !== requester._id.toString()) {
            throw new AppError_1.AppError('Forbidden: You can only copy your own campaigns', 403);
        }
        const newName = input?.name ? input.name.trim() : `${original.name} (Copy)`;
        const duplicated = await campaign_model_1.Campaign.create({
            name: newName,
            pipelineId: original.pipelineId,
            managerId: requester.role === 'MANAGER' ? requester._id : original.managerId,
            agentIds: [...original.agentIds],
            distributionMode: original.distributionMode,
            conditionalRules: original.conditionalRules.map((r) => ({
                field: r.field,
                value: r.value,
                agentIds: [...r.agentIds],
            })),
            fallbackAgentId: original.fallbackAgentId,
            priority: original.priority,
            duplicateMode: original.duplicateMode,
            engagementForm: [...original.engagementForm],
            isActive: true,
        });
        return duplicated;
    }
    static async deleteCampaign(requester, id) {
        if (requester.role !== 'ADMIN') {
            throw new AppError_1.AppError('Forbidden: Only administrators can delete campaigns', 403);
        }
        const campaign = await campaign_model_1.Campaign.findById(id);
        if (!campaign) {
            throw new AppError_1.AppError('Campaign not found', 404);
        }
        // Cascade clean-up: remove all leads and activities associated with this campaign
        if (mongoose_1.default.modelNames().includes('Lead')) {
            const Lead = mongoose_1.default.model('Lead');
            const leads = await Lead.find({ campaignId: id }, '_id');
            const leadIds = leads.map((l) => l._id);
            if (leadIds.length > 0) {
                if (mongoose_1.default.modelNames().includes('Activity')) {
                    const Activity = mongoose_1.default.model('Activity');
                    await Activity.deleteMany({ leadId: { $in: leadIds } });
                }
                await Lead.deleteMany({ campaignId: id });
            }
        }
        await campaign.deleteOne();
    }
}
exports.CampaignService = CampaignService;
