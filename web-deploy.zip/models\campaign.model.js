"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Campaign = void 0;
const mongoose_1 = require("mongoose");
const conditionalRuleSchema = new mongoose_1.Schema({
    field: {
        type: String,
        required: true,
        trim: true,
    },
    value: {
        type: String,
        required: true,
        trim: true,
    },
    agentIds: [
        {
            type: mongoose_1.Schema.Types.ObjectId,
            ref: 'User',
            required: true,
        },
    ],
}, { _id: false });
const engagementQuestionSchema = new mongoose_1.Schema({
    id: {
        type: String,
        required: true,
        trim: true,
    },
    type: {
        type: String,
        enum: [
            'TEXT',
            'SHORT_ANSWER',
            'NUMBER',
            'LONG_ANSWER',
            'DATE',
            'TIME',
            'MULTIPLE_CHOICE',
            'CHECKBOX',
            'DROPDOWN',
        ],
        required: true,
    },
    label: {
        type: String,
        required: true,
        trim: true,
    },
    options: {
        type: [String],
        default: [],
    },
    required: {
        type: Boolean,
        default: false,
    },
}, { _id: false });
const campaignSchema = new mongoose_1.Schema({
    name: {
        type: String,
        required: [true, 'Campaign name is required'],
        trim: true,
    },
    pipelineId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Pipeline',
        required: [true, 'Pipeline ID is required'],
    },
    managerId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'User',
        required: [true, 'Manager ID is required'],
    },
    agentIds: [
        {
            type: mongoose_1.Schema.Types.ObjectId,
            ref: 'User',
        },
    ],
    distributionMode: {
        type: String,
        enum: ['EQUAL', 'CONDITIONAL'],
        default: 'EQUAL',
    },
    conditionalRules: {
        type: [conditionalRuleSchema],
        default: [],
    },
    fallbackAgentId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'User',
        default: null,
    },
    priority: {
        type: String,
        enum: ['HIGH', 'MEDIUM', 'LOW'],
        default: 'MEDIUM',
    },
    duplicateMode: {
        type: String,
        enum: ['SKIP', 'MERGE', 'CREATE_NEW'],
        default: 'SKIP',
    },
    engagementForm: {
        type: [engagementQuestionSchema],
        default: [],
    },
    isActive: {
        type: Boolean,
        default: true,
    },
}, {
    timestamps: true,
});
exports.Campaign = (0, mongoose_1.model)('Campaign', campaignSchema);
