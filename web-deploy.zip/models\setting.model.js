"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Setting = void 0;
const mongoose_1 = require("mongoose");
const settingSchema = new mongoose_1.Schema({
    allowDisposeWithoutFollowUp: {
        type: Boolean,
        default: false,
    },
    followUpMandatoryForNotConnected: {
        type: Boolean,
        default: false,
    },
    reassignAfterHours: {
        type: Number,
        default: 24,
    },
}, {
    timestamps: true,
});
exports.Setting = (0, mongoose_1.model)('Setting', settingSchema);
