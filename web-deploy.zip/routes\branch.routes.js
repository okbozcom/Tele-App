"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const branch_controller_1 = require("../controllers/branch.controller");
const auth_middleware_1 = require("../middleware/auth.middleware");
const validate_middleware_1 = require("../middleware/validate.middleware");
const branch_validation_1 = require("../validations/branch.validation");
const router = (0, express_1.Router)();
// All branch endpoints require authentication
router.use(auth_middleware_1.authenticate);
// Reads: Any authenticated user can get branches (for tabs/pickers)
router.get('/', branch_controller_1.BranchController.listBranches);
// Writes: ADMIN ONLY!
router.post('/', (0, auth_middleware_1.authorize)('ADMIN'), (0, validate_middleware_1.validate)(branch_validation_1.createBranchSchema), branch_controller_1.BranchController.createBranch);
router.delete('/:id', (0, auth_middleware_1.authorize)('ADMIN'), (0, validate_middleware_1.validate)(branch_validation_1.branchIdParamSchema), branch_controller_1.BranchController.deleteBranch);
exports.default = router;
