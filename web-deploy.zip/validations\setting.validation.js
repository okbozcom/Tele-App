"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateSettingSchema = void 0;
const zod_1 = require("zod");
exports.updateSettingSchema = zod_1.z.object({
    body: zod_1.z
        .object({
        allowDisposeWithoutFollowUp: zod_1.z.boolean().optional(),
        followUpMandatoryForNotConnected: zod_1.z.boolean().optional(),
        reassignAfterHours: zod_1.z.number().int().min(1, 'reassignAfterHours must be at least 1 hour').optional(),
    })
        .refine((data) => Object.keys(data).length > 0, {
        message: 'At least one setting field must be provided for update',
    }),
});
