"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.leadsRouter = exports.campaignLeadsRouter = void 0;
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const lead_controller_1 = require("../controllers/lead.controller");
const activity_controller_1 = require("../controllers/activity.controller");
const auth_middleware_1 = require("../middleware/auth.middleware");
const validate_middleware_1 = require("../middleware/validate.middleware");
const lead_validation_1 = require("../validations/lead.validation");
const activity_validation_1 = require("../validations/activity.validation");
// Multer memory storage configuration for CSV uploads (10 MB limit)
const upload = (0, multer_1.default)({
    storage: multer_1.default.memoryStorage(),
    limits: { fileSize: 10 * 1024 * 1024 },
});
// Router for /api/campaigns/:id/leads
exports.campaignLeadsRouter = (0, express_1.Router)({ mergeParams: true });
exports.campaignLeadsRouter.use(auth_middleware_1.authenticate);
exports.campaignLeadsRouter.post('/upload', (0, auth_middleware_1.authorize)('ADMIN', 'MANAGER'), upload.single('file'), lead_controller_1.LeadController.uploadCsv);
exports.campaignLeadsRouter.post('/', (0, auth_middleware_1.authorize)('ADMIN', 'MANAGER', 'AGENT'), (0, validate_middleware_1.validate)(lead_validation_1.createLeadSchema), lead_controller_1.LeadController.createWalkInLead);
exports.campaignLeadsRouter.get('/', (0, validate_middleware_1.validate)(lead_validation_1.listCampaignLeadsQuerySchema), lead_controller_1.LeadController.listCampaignLeads);
exports.campaignLeadsRouter.get('/export', (0, auth_middleware_1.authorize)('ADMIN', 'MANAGER'), lead_controller_1.LeadController.exportCampaignLeadsCsv);
// Router for /api/leads
exports.leadsRouter = (0, express_1.Router)();
// Public / partner webhook route (authenticated via HMAC SHA-256 header)
exports.leadsRouter.post('/webhook', lead_controller_1.LeadController.handleWebhook);
exports.leadsRouter.use(auth_middleware_1.authenticate);
// Tag lead to Manager / Admin (priority alerts across devices)
exports.leadsRouter.post('/tag', lead_controller_1.LeadController.tagLeadToManager);
exports.leadsRouter.post('/:id/tag', lead_controller_1.LeadController.tagLeadToManager);
exports.leadsRouter.get('/tagged', lead_controller_1.LeadController.getTaggedLeads);
exports.leadsRouter.post('/tagged/:id/dismiss', lead_controller_1.LeadController.dismissTaggedLead);
exports.leadsRouter.get('/my', (0, validate_middleware_1.validate)(lead_validation_1.myLeadsQuerySchema), lead_controller_1.LeadController.getMyLeads);
exports.leadsRouter.get('/export', (0, validate_middleware_1.validate)(lead_validation_1.myLeadsQuerySchema), lead_controller_1.LeadController.exportMyLeadsCsv);
exports.leadsRouter.get('/activities/my', activity_controller_1.ActivityController.getUserActivities);
exports.leadsRouter.post('/:id/reassign', (0, auth_middleware_1.authorize)('ADMIN', 'MANAGER'), (0, validate_middleware_1.validate)(lead_validation_1.reassignLeadSchema), lead_controller_1.LeadController.reassignLead);
exports.leadsRouter.post('/bulk-reassign', (0, auth_middleware_1.authorize)('ADMIN', 'MANAGER'), (0, validate_middleware_1.validate)(lead_validation_1.bulkReassignSchema), lead_controller_1.LeadController.bulkReassign);
// Lead disposition: assigned agent or ADMIN/MANAGER
exports.leadsRouter.post('/:id/dispose', (0, validate_middleware_1.validate)(activity_validation_1.disposeLeadSchema), activity_controller_1.ActivityController.disposeLead);
// Lead call activity history
exports.leadsRouter.get('/:id/history', activity_controller_1.ActivityController.getLeadHistory);
// Update lead details (e.g. name, phone, email)
exports.leadsRouter.patch('/:id', (0, validate_middleware_1.validate)(lead_validation_1.updateLeadSchema), lead_controller_1.LeadController.updateLead);
