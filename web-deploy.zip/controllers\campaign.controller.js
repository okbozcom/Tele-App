"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CampaignController = void 0;
const campaign_service_1 = require("../services/campaign.service");
const AppError_1 = require("../utils/AppError");
class CampaignController {
    static async createCampaign(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const campaign = await campaign_service_1.CampaignService.createCampaign(req.user, req.body);
            res.status(201).json({ campaign });
        }
        catch (error) {
            next(error);
        }
    }
    static async listCampaigns(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const campaigns = await campaign_service_1.CampaignService.listCampaigns(req.user);
            res.status(200).json({ campaigns });
        }
        catch (error) {
            next(error);
        }
    }
    static async getCampaign(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const campaign = await campaign_service_1.CampaignService.getCampaignById(req.user, req.params.id);
            res.status(200).json({ campaign });
        }
        catch (error) {
            next(error);
        }
    }
    static async updateCampaign(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const result = await campaign_service_1.CampaignService.updateCampaign(req.user, req.params.id, req.body);
            res.status(200).json({
                campaign: result.campaign,
                ...(result.warning ? { warning: result.warning } : {}),
            });
        }
        catch (error) {
            next(error);
        }
    }
    static async copyCampaign(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            const campaign = await campaign_service_1.CampaignService.copyCampaign(req.user, req.params.id, req.body);
            res.status(201).json({ campaign });
        }
        catch (error) {
            next(error);
        }
    }
    static async deleteCampaign(req, res, next) {
        try {
            if (!req.user) {
                throw new AppError_1.AppError('Authentication required', 401);
            }
            await campaign_service_1.CampaignService.deleteCampaign(req.user, req.params.id);
            res.status(200).json({ message: 'Campaign deleted successfully' });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.CampaignController = CampaignController;
