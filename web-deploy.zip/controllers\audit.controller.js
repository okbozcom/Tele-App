"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditController = void 0;
const audit_service_1 = require("../services/audit.service");
class AuditController {
    static async getLogs(req, res, next) {
        try {
            const { action, resourceType, userId, page, limit } = req.query;
            const result = await audit_service_1.AuditService.getLogs({
                action: action,
                resourceType: resourceType,
                userId: userId,
                page: page ? parseInt(page, 10) : 1,
                limit: limit ? parseInt(limit, 10) : 50,
            });
            res.status(200).json({
                status: 'success',
                data: result,
            });
        }
        catch (err) {
            next(err);
        }
    }
}
exports.AuditController = AuditController;
