"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const campaign_controller_1 = require("../controllers/campaign.controller");
const auth_middleware_1 = require("../middleware/auth.middleware");
const validate_middleware_1 = require("../middleware/validate.middleware");
const campaign_validation_1 = require("../validations/campaign.validation");
const router = (0, express_1.Router)();
// All campaign endpoints require authentication
router.use(auth_middleware_1.authenticate);
// Reads: Any authenticated user can access (scoped internally by role)
router.get('/', campaign_controller_1.CampaignController.listCampaigns);
router.get('/:id', (0, validate_middleware_1.validate)(campaign_validation_1.campaignIdParamSchema), campaign_controller_1.CampaignController.getCampaign);
// Writes: ADMIN and MANAGER only
router.post('/', (0, auth_middleware_1.authorize)('ADMIN', 'MANAGER'), (0, validate_middleware_1.validate)(campaign_validation_1.createCampaignSchema), campaign_controller_1.CampaignController.createCampaign);
router.patch('/:id', (0, auth_middleware_1.authorize)('ADMIN', 'MANAGER'), (0, validate_middleware_1.validate)(campaign_validation_1.updateCampaignSchema), campaign_controller_1.CampaignController.updateCampaign);
router.post('/:id/copy', (0, auth_middleware_1.authorize)('ADMIN', 'MANAGER'), (0, validate_middleware_1.validate)(campaign_validation_1.copyCampaignSchema), campaign_controller_1.CampaignController.copyCampaign);
router.delete('/:id', (0, auth_middleware_1.authorize)('ADMIN'), (0, validate_middleware_1.validate)(campaign_validation_1.campaignIdParamSchema), campaign_controller_1.CampaignController.deleteCampaign);
exports.default = router;
