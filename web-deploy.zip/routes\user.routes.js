"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const user_controller_1 = require("../controllers/user.controller");
const auth_middleware_1 = require("../middleware/auth.middleware");
const validate_middleware_1 = require("../middleware/validate.middleware");
const user_validation_1 = require("../validations/user.validation");
const router = (0, express_1.Router)();
// All user management routes require authentication
router.use(auth_middleware_1.authenticate);
// Create user: ADMIN and MANAGER (managers restricted to AGENT in service logic)
router.post('/', (0, auth_middleware_1.authorize)('ADMIN', 'MANAGER'), (0, validate_middleware_1.validate)(user_validation_1.createUserSchema), user_controller_1.UserController.createUser);
// List users with optional role and isActive filters: ADMIN, MANAGER, and AGENT (for reassignment)
router.get('/', (0, auth_middleware_1.authorize)('ADMIN', 'MANAGER', 'AGENT'), (0, validate_middleware_1.validate)(user_validation_1.listUsersQuerySchema), user_controller_1.UserController.listUsers);
// Bulk create users: ADMIN only
router.post('/bulk', (0, auth_middleware_1.authorize)('ADMIN'), (0, validate_middleware_1.validate)(user_validation_1.bulkCreateUsersSchema), user_controller_1.UserController.bulkCreate);
// Edit user: ADMIN and MANAGER (role change restricted to ADMIN in service logic)
router.patch('/:id', (0, auth_middleware_1.authorize)('ADMIN', 'MANAGER'), (0, validate_middleware_1.validate)(user_validation_1.updateUserSchema), user_controller_1.UserController.updateUser);
// Reset user password: ADMIN only
router.post('/:id/reset-password', (0, auth_middleware_1.authorize)('ADMIN'), (0, validate_middleware_1.validate)(user_validation_1.resetPasswordSchema), user_controller_1.UserController.resetPassword);
exports.default = router;
