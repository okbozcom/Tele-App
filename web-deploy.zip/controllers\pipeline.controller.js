"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PipelineController = void 0;
const pipeline_service_1 = require("../services/pipeline.service");
class PipelineController {
    static async listPipelines(_req, res, next) {
        try {
            const pipelines = await pipeline_service_1.PipelineService.listPipelines();
            res.status(200).json({ pipelines });
        }
        catch (error) {
            next(error);
        }
    }
    static async getPipeline(req, res, next) {
        try {
            const pipeline = await pipeline_service_1.PipelineService.getPipelineById(req.params.id);
            res.status(200).json({ pipeline });
        }
        catch (error) {
            next(error);
        }
    }
    static async createPipeline(req, res, next) {
        try {
            const pipeline = await pipeline_service_1.PipelineService.createPipeline(req.body);
            res.status(201).json({ pipeline });
        }
        catch (error) {
            next(error);
        }
    }
    static async updatePipeline(req, res, next) {
        try {
            const pipeline = await pipeline_service_1.PipelineService.updatePipeline(req.params.id, req.body);
            res.status(200).json({ pipeline });
        }
        catch (error) {
            next(error);
        }
    }
    static async deletePipeline(req, res, next) {
        try {
            await pipeline_service_1.PipelineService.deletePipeline(req.params.id);
            res.status(200).json({ message: 'Pipeline deleted successfully' });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.PipelineController = PipelineController;
