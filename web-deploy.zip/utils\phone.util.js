"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizePhone = void 0;
/**
 * Normalizes phone numbers to digits only and extracts the last 10 digits (standard Indian mobile format).
 * Returns null if the phone number has fewer than 10 digits.
 */
const normalizePhone = (rawPhone) => {
    if (rawPhone === undefined || rawPhone === null) {
        return null;
    }
    const digits = String(rawPhone).replace(/\D/g, '');
    if (digits.length < 10) {
        return null;
    }
    // Extract the last 10 digits
    const last10 = digits.slice(-10);
    // Must be 10 digits
    if (!/^\d{10}$/.test(last10)) {
        return null;
    }
    return last10;
};
exports.normalizePhone = normalizePhone;
