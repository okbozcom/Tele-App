"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const user_model_1 = require("../models/user.model");
const AppError_1 = require("../utils/AppError");
class AuthService {
    static async login(credentials) {
        const { email, password } = credentials;
        const cleanEmail = email.toLowerCase().trim();
        const user = await user_model_1.User.findOne({ email: cleanEmail }).select('+passwordHash');
        if (!user) {
            throw new AppError_1.AppError('Invalid email or password', 401);
        }
        if (!user.isActive) {
            throw new AppError_1.AppError('User account has been deactivated. Please contact an administrator.', 401);
        }
        const isMatch = await user.comparePassword(password);
        if (!isMatch) {
            throw new AppError_1.AppError('Invalid email or password', 401);
        }
        const jwtSecret = process.env.JWT_SECRET;
        if (!jwtSecret) {
            throw new AppError_1.AppError('JWT_SECRET is not configured on the server', 500);
        }
        const expiresIn = (process.env.JWT_EXPIRES_IN || '7d');
        const token = jsonwebtoken_1.default.sign({
            id: user._id.toString(),
            role: user.role,
            tokenVersion: user.tokenVersion || 0,
        }, jwtSecret, { expiresIn });
        return {
            token,
            user,
        };
    }
}
exports.AuthService = AuthService;
