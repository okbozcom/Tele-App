"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditLog = void 0;
const mongoose_1 = require("mongoose");
const auditLogSchema = new mongoose_1.Schema({
    userId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'User',
        default: null,
        index: true,
    },
    userEmail: {
        type: String,
        trim: true,
    },
    userRole: {
        type: String,
        trim: true,
    },
    action: {
        type: String,
        required: true,
        index: true,
    },
    resourceType: {
        type: String,
        required: true,
        index: true,
    },
    resourceId: {
        type: String,
        index: true,
    },
    details: {
        type: mongoose_1.Schema.Types.Mixed,
        default: {},
    },
    ipAddress: {
        type: String,
    },
    userAgent: {
        type: String,
    },
}, {
    timestamps: { createdAt: true, updatedAt: false },
});
auditLogSchema.index({ action: 1, createdAt: -1 });
auditLogSchema.index({ resourceType: 1, resourceId: 1 });
exports.AuditLog = (0, mongoose_1.model)('AuditLog', auditLogSchema);
