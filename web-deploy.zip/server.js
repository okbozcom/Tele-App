"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
const app_1 = __importDefault(require("./app"));
const db_1 = require("./config/db");
const scheduler_service_1 = require("./services/scheduler.service");
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 5000;
const startServer = async () => {
    const server = app_1.default.listen(PORT, () => {
        console.log(`[Server] Tele App Server listening on port ${PORT}`);
        console.log(`[Server] Health check endpoint: http://localhost:${PORT}/api/health`);
    });
    // Connect to MongoDB
    await (0, db_1.connectDB)();
    // Start background schedulers (follow-up checks, inactive agent reassignments)
    scheduler_service_1.schedulerService.start();
    const shutdown = () => {
        console.log('[Server] Gracefully shutting down...');
        scheduler_service_1.schedulerService.stop();
        server.close(() => {
            console.log('[Server] HTTP server closed.');
            process.exit(0);
        });
    };
    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);
};
startServer().catch((error) => {
    console.error('[Server] Failed to start server:', error);
    process.exit(1);
});
