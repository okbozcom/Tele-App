"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_1 = __importDefault(require("dotenv"));
const path_1 = __importDefault(require("path"));
// Load environment variables from .env
dotenv_1.default.config();
dotenv_1.default.config({ path: path_1.default.resolve(__dirname, '../../.env') });
const mongoose_1 = __importDefault(require("mongoose"));
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const user_model_1 = require("../models/user.model");
const pipeline_model_1 = require("../models/pipeline.model");
const seedDatabase = async () => {
    const mongoURI = process.env.MONGO_URI ||
        process.env.MONGODB_URI ||
        'mongodb://localhost:27017/tele_app';
    try {
        console.log('[Seed] Connecting to MongoDB...');
        await mongoose_1.default.connect(mongoURI);
        console.log('[Seed] Connected to MongoDB.');
        // 1. Seed Admin
        const adminEmail = 'admin@example.com';
        const existingAdmin = await user_model_1.User.findOne({ email: adminEmail });
        if (existingAdmin) {
            console.log(`[Seed] Admin user already exists (${adminEmail}). Skipping creation.`);
        }
        else {
            const passwordHash = await bcryptjs_1.default.hash('Admin@123', 10);
            const admin = await user_model_1.User.create({
                name: 'System Admin',
                email: adminEmail,
                phone: '1234567890',
                passwordHash,
                role: 'ADMIN',
                isActive: true,
                canReceiveLeads: false,
            });
            console.log(`[Seed] Default ADMIN user created successfully!`);
            console.log(`[Seed] ID: ${admin._id.toString()}`);
            console.log(`[Seed] Email: ${admin.email}`);
            console.log(`[Seed] Role: ${admin.role}`);
        }
        // 2. Seed Default Pipeline
        const defaultPipelineName = 'Sales Pipeline';
        const existingPipeline = await pipeline_model_1.Pipeline.findOne({ name: defaultPipelineName });
        if (existingPipeline) {
            console.log(`[Seed] Pipeline '${defaultPipelineName}' already exists. Skipping creation.`);
        }
        else {
            const pipeline = await pipeline_model_1.Pipeline.create({
                name: defaultPipelineName,
                stages: [
                    { name: 'New', isClosed: false, tags: [], order: 0 },
                    { name: 'Interested', isClosed: false, tags: ['hot', 'warm', 'cold'], order: 1 },
                    { name: 'Follow Up', isClosed: false, tags: [], order: 2 },
                    { name: 'Not Interested', isClosed: true, tags: [], order: 3 },
                    { name: 'Converted', isClosed: true, tags: [], order: 4 },
                    { name: 'Lost', isClosed: true, tags: [], order: 5 },
                ],
            });
            console.log(`[Seed] Default '${defaultPipelineName}' created successfully with ${pipeline.stages.length} stages!`);
            console.log(`[Seed] Pipeline ID: ${pipeline._id.toString()}`);
        }
        await mongoose_1.default.disconnect();
        console.log('[Seed] Database disconnected.');
        process.exit(0);
    }
    catch (error) {
        console.error('[Seed] Error seeding database:', error);
        await mongoose_1.default.disconnect().catch(() => { });
        process.exit(1);
    }
};
seedDatabase();
