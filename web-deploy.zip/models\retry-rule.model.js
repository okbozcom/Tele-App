"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RetryRule = void 0;
const mongoose_1 = require("mongoose");
const activity_model_1 = require("./activity.model");
const retryStepSchema = new mongoose_1.Schema({
    delayMinutes: {
        type: Number,
        required: true,
        min: 1,
    },
}, { _id: false });
const retryRuleSchema = new mongoose_1.Schema({
    reason: {
        type: String,
        enum: activity_model_1.NotConnectedReasons,
        required: true,
        unique: true,
        index: true,
    },
    enabled: {
        type: Boolean,
        default: true,
    },
    steps: {
        type: [retryStepSchema],
        default: [],
    },
}, {
    timestamps: true,
});
exports.RetryRule = (0, mongoose_1.model)('RetryRule', retryRuleSchema);
